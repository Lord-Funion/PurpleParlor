<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Security\Csrf;
use App\Http\ErrorPage;

final class CsrfMiddleware implements MiddlewareInterface
{
    public function __construct(private readonly Csrf $csrf, private readonly string $scope = 'default')
    {
    }

    public function process(Request $request, callable $next): Response
    {
        if (in_array($request->method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            return $next($request);
        }
        $token = $request->header('x-csrf-token') ?? (is_string($request->body['_csrf'] ?? null) ? $request->body['_csrf'] : null);
        if (!$this->csrf->validate($token, $this->scope)) {
            return $request->expectsJson()
                ? Response::json(['error' => 'Your session token expired. Refresh and try again.'], 419)
                : ErrorPage::response(419);
        }
        return $next($request);
    }
}
