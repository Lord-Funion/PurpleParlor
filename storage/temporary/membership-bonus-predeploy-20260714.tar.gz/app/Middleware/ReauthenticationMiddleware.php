<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Auth\SessionManager;
use App\Core\Request;
use App\Core\Response;

final class ReauthenticationMiddleware implements MiddlewareInterface
{
    public function __construct(private readonly SessionManager $sessions, private readonly ?string $requiredRole = null)
    {
    }

    public function process(Request $request, callable $next): Response
    {
        if (!$this->sessions->privileged()) {
            return $request->expectsJson()
                ? Response::json(['error' => 'Recent reauthentication is required.'], 401)
                : Response::redirect('/confirm-password?return=' . rawurlencode($request->uri));
        }
        if ($this->requiredRole !== null) {
            $user = $request->attribute('user');
            if (!is_object($user) || !in_array($this->requiredRole, (array) ($user->roles ?? []), true)) {
                return Response::json(['error' => 'This action requires the Adult Owner.'], 403);
            }
        }
        return $next($request);
    }
}
