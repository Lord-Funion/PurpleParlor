<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Auth\AuthService;
use App\Core\Request;
use App\Core\Response;

final class AuthMiddleware implements MiddlewareInterface
{
    public function __construct(private readonly AuthService $auth)
    {
    }

    public function process(Request $request, callable $next): Response
    {
        $user = $this->auth->currentUser();
        if ($user === null) {
            return $request->expectsJson()
                ? Response::json(['error' => 'Authentication required.'], 401)
                : Response::redirect('/login?return=' . rawurlencode($request->uri));
        }
        return $next($request->withAttribute('user', $user)->withAttribute('user_id', $user->id));
    }
}
