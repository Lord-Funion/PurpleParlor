<?php

declare(strict_types=1);

namespace App\Security;

final class Csrf
{
    public function __construct(private readonly int $ttlSeconds = 7200)
    {
    }

    public function token(string $scope = 'default'): string
    {
        $this->ensureSession();
        $record = $_SESSION['_csrf'][$scope] ?? null;
        if (!is_array($record) || (int) ($record['expires'] ?? 0) < time()) {
            $record = ['token' => bin2hex(random_bytes(32)), 'expires' => time() + $this->ttlSeconds];
            $_SESSION['_csrf'][$scope] = $record;
        }
        return (string) $record['token'];
    }

    public function validate(?string $token, string $scope = 'default', bool $rotate = false): bool
    {
        $this->ensureSession();
        $record = $_SESSION['_csrf'][$scope] ?? null;
        $valid = is_string($token) && is_array($record)
            && (int) ($record['expires'] ?? 0) >= time()
            && hash_equals((string) ($record['token'] ?? ''), $token);
        if ($valid && $rotate) {
            unset($_SESSION['_csrf'][$scope]);
        }
        return $valid;
    }

    private function ensureSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            throw new \RuntimeException('A secure PHP session must be started before using CSRF protection.');
        }
    }
}
