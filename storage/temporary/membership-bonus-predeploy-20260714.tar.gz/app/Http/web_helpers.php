<?php

declare(strict_types=1);

use App\Http\UrlGenerator;

if (!function_exists('route')) {
    /** @param array<string, scalar> $parameters */
    function route(string $name, array $parameters = [], bool $absolute = false): string
    {
        return UrlGenerator::route($name, $parameters, $absolute);
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        $path = ltrim($path, '/');
        return '/assets/' . $path;
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return '';
        }
        $record = $_SESSION['_csrf']['default'] ?? null;
        if (!is_array($record) || !is_string($record['token'] ?? null) || (int) ($record['expires'] ?? 0) < time()) {
            $record = ['token' => bin2hex(random_bytes(32)), 'expires' => time() + 7200];
            $_SESSION['_csrf']['default'] = $record;
        }
        return (string) $record['token'];
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): string
    {
        return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
    }
}

if (!function_exists('old')) {
    function old(string $key, mixed $default = ''): mixed
    {
        return $_SESSION['_old'][$key] ?? $default;
    }
}
