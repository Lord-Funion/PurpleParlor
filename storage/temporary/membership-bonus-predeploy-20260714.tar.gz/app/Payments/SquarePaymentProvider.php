<?php

declare(strict_types=1);

namespace App\Payments;

use App\Core\Config;
use RuntimeException;

final class SquarePaymentProvider implements PaymentProviderInterface
{
    public function __construct(
        private readonly Config $config,
        private readonly PaymentGate $gate,
        private readonly HttpClient $http,
    ) {
    }

    public function name(): string { return 'square'; }

    public function createOneTimeCheckout(PurchaseRequest $request): CheckoutResult
    {
        $this->gate->assertCheckoutAllowed($this->name());
        if ($request->paymentSourceToken !== null && $request->paymentSourceToken !== '') {
            $payload = [
                'source_id' => $request->paymentSourceToken,
                'idempotency_key' => $request->idempotencyKey,
                'amount_money' => ['amount' => $request->amountCents, 'currency' => $request->currency],
                'location_id' => (string) $this->config->get('payments.square.location_id'),
                'reference_id' => $request->productKey,
                'note' => 'Fixed cosmetic or entertainment feature; no virtual currency.',
            ];
            $response = $this->api('POST', '/v2/payments', $payload);
            if ($response['status'] < 200 || $response['status'] >= 300 || !is_array($response['json']['payment'] ?? null)) {
                return $this->failure($response);
            }
            $payment = $response['json']['payment'];
            return new CheckoutResult(true, strtolower((string) ($payment['status'] ?? 'pending')), (string) ($payment['id'] ?? ''),
                null, null, $this->safeProviderData($payment));
        }

        // Hosted Payment Links are the cPanel-friendly fallback when Web Payments SDK is unavailable.
        $payload = [
            'idempotency_key' => $request->idempotencyKey,
            'quick_pay' => [
                'name' => substr($request->productKey, 0, 255),
                'price_money' => ['amount' => $request->amountCents, 'currency' => $request->currency],
                'location_id' => (string) $this->config->get('payments.square.location_id'),
            ],
            'checkout_options' => ['redirect_url' => $request->returnUrl, 'ask_for_shipping_address' => false],
            'pre_populated_data' => [],
            'payment_note' => 'Fixed cosmetic or entertainment feature; no virtual currency.',
        ];
        $response = $this->api('POST', '/v2/online-checkout/payment-links', $payload);
        if ($response['status'] < 200 || $response['status'] >= 300 || !is_array($response['json']['payment_link'] ?? null)) {
            return $this->failure($response);
        }
        $link = $response['json']['payment_link'];
        return new CheckoutResult(true, 'pending', (string) ($link['id'] ?? ''), (string) ($link['url'] ?? ''), null, $this->safeProviderData($link));
    }

    public function createSubscription(SubscriptionRequest $request): CheckoutResult
    {
        return new CheckoutResult(false, 'unsupported', null, null, 'square_recurring_not_enabled');
    }

    public function cancelSubscription(string $externalId): ProviderResult
    {
        return new ProviderResult(false, 'unsupported', $externalId, 'square_recurring_not_enabled');
    }

    public function refundPayment(string $externalId, int $amountCents, ?string $idempotencyKey = null): ProviderResult
    {
        $this->gate->assertCheckoutAllowed($this->name());
        $this->assertExternalId($externalId);
        if ($amountCents <= 0) {
            return new ProviderResult(false, 'failed', $externalId, 'invalid_amount');
        }
        $idempotency = 'refund_' . substr(hash('sha256', $idempotencyKey ?: $externalId . ':' . $amountCents), 0, 36);
        $response = $this->api('POST', '/v2/refunds', [
            'idempotency_key' => $idempotency,
            'payment_id' => $externalId,
            'amount_money' => ['amount' => $amountCents, 'currency' => (string) $this->config->get('payments.currency', 'USD')],
            'reason' => 'Approved customer refund',
        ]);
        $refund = is_array($response['json']['refund'] ?? null) ? $response['json']['refund'] : null;
        return $response['status'] >= 200 && $response['status'] < 300 && $refund !== null
            ? new ProviderResult(true, strtolower((string) ($refund['status'] ?? 'pending')), (string) ($refund['id'] ?? ''), null, $this->safeProviderData($refund))
            : new ProviderResult(false, 'failed', $externalId, $this->errorCode($response));
    }

    public function retrieveSubscription(string $externalId): ProviderSubscription
    {
        throw new RuntimeException('Square recurring subscriptions are intentionally not enabled.');
    }

    public function verifyWebhook(string $rawBody, array $headers): bool
    {
        $signature = $this->header($headers, 'x-square-hmacsha256-signature');
        $key = (string) $this->config->get('payments.square.signature_key', '');
        $url = (string) $this->config->get('payments.square.webhook_url', '');
        if ($signature === null || $key === '' || !str_starts_with($url, 'https://')) {
            return false;
        }
        $expected = base64_encode(hash_hmac('sha256', $url . $rawBody, $key, true));
        return hash_equals($expected, $signature);
    }

    public function parseWebhook(string $rawBody, array $headers): PaymentEvent
    {
        $event = json_decode($rawBody, true, 64, JSON_THROW_ON_ERROR);
        if (!is_array($event) || !is_array($event['data']['object'] ?? null)) {
            throw new RuntimeException('Malformed Square webhook event.');
        }
        $type = (string) ($event['type'] ?? '');
        $object = $event['data']['object'];
        $payment = is_array($object['payment'] ?? null) ? $object['payment'] : null;
        $refund = is_array($object['refund'] ?? null) ? $object['refund'] : null;
        $dispute = is_array($object['dispute'] ?? null) ? $object['dispute'] : null;
        $money = $payment['amount_money'] ?? $refund['amount_money'] ?? $dispute['amount_money'] ?? null;
        $status = match (true) {
            str_contains($type, 'refund') => strtolower((string) ($refund['status'] ?? 'refunded')),
            str_contains($type, 'dispute') => 'disputed',
            $payment !== null => match (strtoupper((string) ($payment['status'] ?? ''))) {
                'COMPLETED' => 'completed', 'CANCELED', 'FAILED' => 'failed', default => 'pending',
            },
            default => 'unknown',
        };
        return new PaymentEvent('square', (string) ($event['event_id'] ?? ''), $type, $status,
            $payment['id'] ?? $refund['payment_id'] ?? $dispute['disputed_payment']['payment_id'] ?? null,
            null, $refund['id'] ?? null, $dispute['id'] ?? null,
            is_array($money) && isset($money['amount']) ? (int) $money['amount'] : null,
            is_array($money) ? ($money['currency'] ?? null) : null, $event['created_at'] ?? null, $event);
    }

    /** @return array{status:int,headers:array<string,string>,body:string,json:array<string,mixed>} */
    private function api(string $method, string $path, ?array $payload = null): array
    {
        $token = trim((string) $this->config->get('payments.square.access_token', ''));
        if ($token === '') {
            throw new PaymentsDisabled('Square credentials are not configured.');
        }
        $headers = ['Authorization: Bearer ' . $token, 'Accept: application/json', 'Square-Version: ' . (string) $this->config->get('payments.square.api_version', '2026-05-20')];
        $body = null;
        if ($payload !== null) {
            $headers[] = 'Content-Type: application/json';
            $body = json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        }
        return $this->http->request($method, $this->baseUrl() . $path, $headers, $body);
    }

    private function baseUrl(): string
    {
        return $this->config->get('payments.square.environment') === 'live' ? 'https://connect.squareup.com' : 'https://connect.squareupsandbox.com';
    }

    private function header(array $headers, string $name): ?string
    {
        foreach ($headers as $key => $value) {
            if (strtolower((string) $key) === strtolower($name)) {
                return is_array($value) ? ($value[0] ?? null) : (string) $value;
            }
        }
        return null;
    }

    private function failure(array $response): CheckoutResult
    {
        return new CheckoutResult(false, 'failed', null, null, $this->errorCode($response));
    }

    private function errorCode(array $response): string
    {
        return (string) ($response['json']['errors'][0]['code'] ?? 'provider_error');
    }

    private function safeProviderData(array $data): array
    {
        unset($data['card_details'], $data['source_id'], $data['access_token']);
        return $data;
    }

    private function assertExternalId(string $id): void
    {
        if (!preg_match('/^[A-Za-z0-9_-]{3,191}$/', $id)) {
            throw new RuntimeException('Invalid Square resource identifier.');
        }
    }
}
