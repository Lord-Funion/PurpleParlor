# Square Setup

Square is the optional provider for fixed, nonconsumable cosmetic products. The Adult Owner owns and verifies the seller and payout accounts and supplies sandbox/live application, access-token, location, webhook-signature, and API-version values directly in private configuration.

This release enables only Square Web Payments SDK card tokenization. Google Pay, Cash App Pay, and Apple Pay buttons are intentionally not rendered: each requires its own real-amount payment request, method-specific tokenization or event flow, merchant/domain approval, sandbox tests, and live verification. Provider availability alone is not permission to expose a wallet. Enabling one later requires an Adult Owner-approved implementation and regression-test change; it is not an `.env` toggle.

The server creates payments with idempotency keys. Verified webhooks—not a success page—grant fixed entitlements. Test success, failure, refund, dispute, duplicate request/event, invalid signature, and reconciliation in sandbox. See Parts P and Q of [SETUP_EVERYTHING.md](SETUP_EVERYTHING.md).

Before account configuration, compare the integration with Square's current official [webhook signature validation](https://developer.squareup.com/docs/webhooks/step3validate), [webhook overview](https://developer.squareup.com/docs/webhooks/overview), and [Create Payment reference](https://developer.squareup.com/reference/square/payments-api/createpayment). The configured Square API version is explicit and must be reviewed before upgrading.
