<aside class="currency-disclaimer" aria-label="Virtual currency notice">
    <span class="disclaimer-icon" aria-hidden="true">◉</span>
    <p><strong>Play-money only.</strong> Virtual currency has no cash value and cannot be purchased, transferred, redeemed, withdrawn, or exchanged for anything of value.</p>
</aside>
