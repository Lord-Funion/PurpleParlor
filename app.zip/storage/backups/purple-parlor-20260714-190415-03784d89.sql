-- The Purple Parlor database backup
-- Created UTC: 2026-07-14T19:04:15+00:00
SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

DROP TABLE IF EXISTS `achievements`;
CREATE TABLE `achievements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `achievement_key` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `reward_coins` bigint(20) NOT NULL DEFAULT 0,
  `reward_stars` bigint(20) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `achievement_key` (`achievement_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `achievements` (`id`,`achievement_key`,`name`,`description`,`reward_coins`,`reward_stars`,`active`,`created_at`) VALUES ('1','welcome','Welcome to the Parlor','Create and verify an account.','0','25','1','2026-07-14 13:06:04');
INSERT INTO `achievements` (`id`,`achievement_key`,`name`,`description`,`reward_coins`,`reward_stars`,`active`,`created_at`) VALUES ('2','first_round','First Round','Complete any game round.','250','10','1','2026-07-14 13:06:04');
INSERT INTO `achievements` (`id`,`achievement_key`,`name`,`description`,`reward_coins`,`reward_stars`,`active`,`created_at`) VALUES ('3','rules_reader','Rules Reader','Read a game rules page.','100','5','1','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `admin_audit_logs`;
CREATE TABLE `admin_audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `administrator_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(100) NOT NULL,
  `target_id` varchar(191) DEFAULT NULL,
  `previous_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`previous_json`)),
  `new_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_json`)),
  `reason` varchar(500) DEFAULT NULL,
  `request_id` varchar(64) NOT NULL,
  `ip_hash` varchar(64) DEFAULT NULL,
  `previous_hash` varchar(64) NOT NULL,
  `entry_hash` varchar(64) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `administrator_id` (`administrator_id`),
  KEY `idx_audit_created` (`created_at`),
  CONSTRAINT `admin_audit_logs_ibfk_1` FOREIGN KEY (`administrator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `advertising_slots`;
CREATE TABLE `advertising_slots` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slot_key` varchar(100) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `configuration_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration_json`)),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slot_key` (`slot_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `advertising_slots` (`id`,`slot_key`,`provider`,`enabled`,`configuration_json`,`updated_at`) VALUES ('1','home_lounge_footer','placeholder','0','{\"headline\":\"Sponsor a thoughtfully designed lounge placement\",\"body\":\"Partnerships are reviewed by the Adult Owner and are always labeled and separated from play controls.\",\"cta_label\":\"Sponsorship details\",\"destination_url\":\"/sponsor\",\"frequency_cap_per_session\":1}','2026-07-14 13:06:04');
INSERT INTO `advertising_slots` (`id`,`slot_key`,`provider`,`enabled`,`configuration_json`,`updated_at`) VALUES ('2','game_lobby_footer','placeholder','0','{\"headline\":\"Support original play-money entertainment\",\"body\":\"Learn about fixed, clearly disclosed lounge sponsorships with no effect on games, odds, or fictional payouts.\",\"cta_label\":\"Advertising policy\",\"destination_url\":\"/legal/advertising\",\"frequency_cap_per_session\":1}','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `age_confirmations`;
CREATE TABLE `age_confirmations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `policy_version` varchar(32) NOT NULL,
  `confirmed_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `age_confirmations` (`id`,`policy_version`,`confirmed_at`) VALUES ('1','1','2026-07-14 13:07:19');
INSERT INTO `age_confirmations` (`id`,`policy_version`,`confirmed_at`) VALUES ('2','1','2026-07-14 13:07:36');
INSERT INTO `age_confirmations` (`id`,`policy_version`,`confirmed_at`) VALUES ('3','1','2026-07-14 15:35:07');
INSERT INTO `age_confirmations` (`id`,`policy_version`,`confirmed_at`) VALUES ('4','1','2026-07-14 15:52:56');

DROP TABLE IF EXISTS `analytics_events`;
CREATE TABLE `analytics_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(64) NOT NULL,
  `visitor_hash` varchar(64) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_category` varchar(32) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata_json`)),
  `occurred_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_analytics_expiry` (`expires_at`),
  CONSTRAINT `analytics_events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `backup_records`;
CREATE TABLE `backup_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `path_hash` varchar(64) NOT NULL,
  `checksum_sha256` varchar(64) NOT NULL,
  `size_bytes` bigint(20) NOT NULL,
  `status` varchar(32) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `checkout_intents`;
CREATE TABLE `checkout_intents` (
  `intent_key` varchar(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `checkout_type` varchar(32) NOT NULL,
  `item_key` varchar(100) NOT NULL,
  `billing_period` varchar(16) NOT NULL DEFAULT '',
  `provider` varchar(32) NOT NULL,
  `provider_environment` varchar(16) NOT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'processing',
  `provider_external_id` varchar(191) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `terminal_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`intent_key`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  UNIQUE KEY `user_id` (`user_id`,`checkout_type`,`item_key`,`billing_period`,`provider`,`provider_environment`),
  CONSTRAINT `checkout_intents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(254) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'new',
  `spam_score` int(11) NOT NULL DEFAULT 0,
  `submitted_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `contact_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cron_locks`;
CREATE TABLE `cron_locks` (
  `lock_key` varchar(100) NOT NULL,
  `owner_token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `acquired_at` datetime NOT NULL,
  PRIMARY KEY (`lock_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cron_runs`;
CREATE TABLE `cron_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `run_key` varchar(100) NOT NULL,
  `status` varchar(32) NOT NULL,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  `details_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details_json`)),
  PRIMARY KEY (`id`),
  KEY `idx_cron_runs_key` (`run_key`,`started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('1','main_dispatcher','failed','2026-07-14 15:45:02','2026-07-14 15:45:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('2','main_dispatcher','failed','2026-07-14 15:50:02','2026-07-14 15:50:03','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('3','main_dispatcher','failed','2026-07-14 15:55:02','2026-07-14 15:55:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('4','main_dispatcher','failed','2026-07-14 16:00:02','2026-07-14 16:00:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('5','main_dispatcher','failed','2026-07-14 16:05:01','2026-07-14 16:05:01','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('6','main_dispatcher','failed','2026-07-14 16:10:02','2026-07-14 16:10:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('7','main_dispatcher','failed','2026-07-14 16:15:03','2026-07-14 16:15:03','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('8','main_dispatcher','failed','2026-07-14 16:20:02','2026-07-14 16:20:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('9','main_dispatcher','failed','2026-07-14 16:25:02','2026-07-14 16:25:03','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('10','main_dispatcher','failed','2026-07-14 16:30:02','2026-07-14 16:30:03','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('11','main_dispatcher','failed','2026-07-14 16:35:01','2026-07-14 16:35:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('12','main_dispatcher','failed','2026-07-14 16:39:36','2026-07-14 16:39:56','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('13','main_dispatcher','failed','2026-07-14 16:39:56','2026-07-14 16:39:56','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('14','main_dispatcher','failed','2026-07-14 16:40:02','2026-07-14 16:40:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('15','main_dispatcher','failed','2026-07-14 16:43:43','2026-07-14 16:43:49','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('16','main_dispatcher','failed','2026-07-14 16:45:02','2026-07-14 16:45:02','{\"error\":\"Cron task failed; inspect private logs.\",\"error_type\":\"PDOException\"}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('17','main_dispatcher','completed','2026-07-14 16:47:45','2026-07-14 16:47:45','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":3,\"daily_created\":1,\"weekly_created\":2},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":5,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 16:47:45\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('18','main_dispatcher','completed','2026-07-14 16:50:02','2026-07-14 16:50:17','{\"mail\":{\"sent\":2,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 16:50:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('19','main_dispatcher','completed','2026-07-14 16:55:02','2026-07-14 16:55:10','{\"mail\":{\"sent\":1,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 16:55:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('20','main_dispatcher','completed','2026-07-14 17:00:02','2026-07-14 17:00:16','{\"mail\":{\"sent\":2,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:00:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('21','main_dispatcher','completed','2026-07-14 17:05:03','2026-07-14 17:05:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:05:03\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('22','main_dispatcher','completed','2026-07-14 17:10:02','2026-07-14 17:10:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:10:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('23','main_dispatcher','completed','2026-07-14 17:15:02','2026-07-14 17:15:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:15:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('24','main_dispatcher','completed','2026-07-14 17:20:02','2026-07-14 17:20:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":1,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:20:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('25','main_dispatcher','completed','2026-07-14 17:25:02','2026-07-14 17:25:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:25:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('26','main_dispatcher','completed','2026-07-14 17:30:03','2026-07-14 17:30:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:30:03\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('27','main_dispatcher','completed','2026-07-14 17:35:01','2026-07-14 17:35:01','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:35:01\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('28','main_dispatcher','completed','2026-07-14 17:40:01','2026-07-14 17:40:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:40:01\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('29','main_dispatcher','completed','2026-07-14 17:45:02','2026-07-14 17:45:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:45:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('30','main_dispatcher','completed','2026-07-14 17:50:02','2026-07-14 17:50:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:50:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('31','main_dispatcher','completed','2026-07-14 17:55:02','2026-07-14 17:55:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:55:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('32','main_dispatcher','completed','2026-07-14 17:56:25','2026-07-14 17:56:25','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 17:56:25\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('33','main_dispatcher','completed','2026-07-14 18:00:02','2026-07-14 18:00:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":4,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:00:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('34','main_dispatcher','completed','2026-07-14 18:05:01','2026-07-14 18:05:01','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":3,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:05:01\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('35','main_dispatcher','completed','2026-07-14 18:10:02','2026-07-14 18:10:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:10:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('36','main_dispatcher','completed','2026-07-14 18:15:02','2026-07-14 18:15:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:15:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('37','main_dispatcher','completed','2026-07-14 18:20:02','2026-07-14 18:20:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:20:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('38','main_dispatcher','completed','2026-07-14 18:25:01','2026-07-14 18:25:01','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:25:01\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('39','main_dispatcher','completed','2026-07-14 18:30:02','2026-07-14 18:30:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:30:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('40','main_dispatcher','completed','2026-07-14 18:35:02','2026-07-14 18:35:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:35:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('41','main_dispatcher','completed','2026-07-14 18:40:02','2026-07-14 18:40:03','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:40:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('42','main_dispatcher','completed','2026-07-14 18:45:01','2026-07-14 18:45:01','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:45:01\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('43','main_dispatcher','completed','2026-07-14 18:50:02','2026-07-14 18:50:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:50:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('44','main_dispatcher','completed','2026-07-14 18:55:02','2026-07-14 18:55:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 18:55:02\"}}');
INSERT INTO `cron_runs` (`id`,`run_key`,`status`,`started_at`,`finished_at`,`details_json`) VALUES ('45','main_dispatcher','completed','2026-07-14 19:00:01','2026-07-14 19:00:02','{\"mail\":{\"sent\":0,\"failed\":0},\"subscriptions\":{\"checked\":0,\"updated\":0,\"errors\":[]},\"expired_grace_periods\":0,\"expired_entitlements\":0,\"membership_bonuses\":{\"checked\":0,\"eligible\":0,\"granted\":0,\"already_granted\":0,\"coins_granted\":0,\"reward_date\":\"2026-07-14\"},\"retried_webhooks\":0,\"missions\":{\"expired\":0,\"created\":0,\"daily_created\":0,\"weekly_created\":0},\"backup\":{\"status\":\"not_due\"},\"cleanup\":{\"sessions\":0,\"remember_tokens\":0,\"rate_limits\":0,\"idempotency\":0,\"webhook_payloads\":0,\"analytics\":0,\"temporary_files\":0},\"health\":{\"status\":\"review\",\"passed\":29,\"total\":31,\"failed\":[\"private_config_permissions\",\"backup_freshness\"],\"persisted\":true,\"checked_at\":\"2026-07-14 19:00:01\"}}');

DROP TABLE IF EXISTS `daily_reward_claims`;
CREATE TABLE `daily_reward_claims` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `reward_date` date NOT NULL,
  `amount` bigint(20) NOT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `claimed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  UNIQUE KEY `user_id` (`user_id`,`reward_date`),
  CONSTRAINT `daily_reward_claims_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `data_export_requests`;
CREATE TABLE `data_export_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(32) NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `data_export_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `disputes`;
CREATE TABLE `disputes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `provider` varchar(32) NOT NULL,
  `external_id` varchar(191) NOT NULL,
  `status` varchar(32) NOT NULL,
  `amount_cents` bigint(20) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`,`external_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `disputes_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `email_queue`;
CREATE TABLE `email_queue` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recipient_email` varchar(254) NOT NULL,
  `recipient_name` varchar(100) DEFAULT NULL,
  `template_key` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `html_body` text NOT NULL,
  `text_body` text NOT NULL,
  `headers_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`headers_json`)),
  `status` varchar(32) NOT NULL DEFAULT 'queued',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `available_at` datetime NOT NULL,
  `locked_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `last_error` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_queue_due` (`status`,`available_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `email_queue` (`id`,`recipient_email`,`recipient_name`,`template_key`,`subject`,`html_body`,`text_body`,`headers_json`,`status`,`attempts`,`available_at`,`locked_at`,`sent_at`,`last_error`,`created_at`) VALUES ('8','lordfunion@gmail.com','lordfunion','email.verify','Verify your Purple Parlor email','<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\"><title>Verify your Purple Parlor email</title></head><body style=\"margin:0;background:#160c1f;color:#fff9e8;font-family:Segoe UI,Arial,sans-serif\"><div style=\"display:none;max-height:0;overflow:hidden;opacity:0\">Finish creating your play-money Parlor account.</div><table role=\"presentation\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" style=\"background:#160c1f\"><tr><td align=\"center\" style=\"padding:30px 12px\"><table role=\"presentation\" width=\"600\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%;max-width:600px\"><tr><td style=\"padding:18px 22px;text-align:center\"><a href=\"https://purpleparlor.lordfunion.dev\" style=\"color:#ffe2a0;text-decoration:none;font-family:Georgia,serif;font-size:28px;font-weight:bold\">♛ The Purple Parlor</a><div style=\"color:#bba7c5;font-size:12px;letter-spacing:2px;text-transform:uppercase\">By Lord Funion</div></td></tr><tr><td style=\"border:1px solid #654171;border-radius:20px;background:#281432;padding:32px 28px;box-shadow:0 16px 40px rgba(0,0,0,.25)\"><p style=\"margin:0 0 8px;color:#e8b85d;font-size:12px;font-weight:bold;letter-spacing:2px;text-transform:uppercase\">One quick check</p><h1 style=\"margin:0 0 16px;font-family:Georgia,serif;font-size:32px;line-height:1.15\">Verify your email</h1><p style=\"margin:0 0 20px;color:#ddd0e6;line-height:1.6\">Hello lordfunion. Confirm this address to save progress and use account features.</p><p style=\"margin:24px 0;text-align:center\"><a href=\"https://purpleparlor.lordfunion.dev/verify-email/dc373d166c8bf4d4286a013d4f1f1ef1b231afc855035ca05be3d25a137344e9\" style=\"display:inline-block;border-radius:999px;background:#e8b85d;color:#241207;font-weight:bold;padding:13px 24px;text-decoration:none\">Verify email</a></p><p style=\"margin:0;color:#ac9ab8;font-size:13px;line-height:1.5\">This link expires in 24 hours. If you did not create an account, ignore this message. Never forward this link.</p>\n</td></tr><tr><td style=\"padding:20px 12px;color:#bba7c5;font-size:12px;line-height:1.6;text-align:center\"><p style=\"margin:0 0 8px\"><strong style=\"color:#ffe2a0\">Play-money only.</strong> Virtual currency has no cash value and cannot be purchased, transferred, redeemed, withdrawn, or exchanged for anything of value.</p><p style=\"margin:0\">No real-money wagering or cash prizes. Need help? <a href=\"mailto:support@lordfunion.dev\" style=\"color:#d9b8ef\">support@lordfunion.dev</a></p></td></tr></table></td></tr></table></body></html>\n','Verify your Purple Parlor email within 24 hours:\nhttps://purpleparlor.lordfunion.dev/verify-email/dc373d166c8bf4d4286a013d4f1f1ef1b231afc855035ca05be3d25a137344e9\nIf you did not create this account, ignore this message.','[]','sent','1','2026-07-14 16:59:20',NULL,'2026-07-14 17:00:10',NULL,'2026-07-14 16:59:20');
INSERT INTO `email_queue` (`id`,`recipient_email`,`recipient_name`,`template_key`,`subject`,`html_body`,`text_body`,`headers_json`,`status`,`attempts`,`available_at`,`locked_at`,`sent_at`,`last_error`,`created_at`) VALUES ('9','lordfunion@gmail.com','lordfunion','email.verify','Verify your Purple Parlor email','<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\"><title>Verify your Purple Parlor email</title></head><body style=\"margin:0;background:#160c1f;color:#fff9e8;font-family:Segoe UI,Arial,sans-serif\"><div style=\"display:none;max-height:0;overflow:hidden;opacity:0\">Finish creating your play-money Parlor account.</div><table role=\"presentation\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" style=\"background:#160c1f\"><tr><td align=\"center\" style=\"padding:30px 12px\"><table role=\"presentation\" width=\"600\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%;max-width:600px\"><tr><td style=\"padding:18px 22px;text-align:center\"><a href=\"https://purpleparlor.lordfunion.dev\" style=\"color:#ffe2a0;text-decoration:none;font-family:Georgia,serif;font-size:28px;font-weight:bold\">♛ The Purple Parlor</a><div style=\"color:#bba7c5;font-size:12px;letter-spacing:2px;text-transform:uppercase\">By Lord Funion</div></td></tr><tr><td style=\"border:1px solid #654171;border-radius:20px;background:#281432;padding:32px 28px;box-shadow:0 16px 40px rgba(0,0,0,.25)\"><p style=\"margin:0 0 8px;color:#e8b85d;font-size:12px;font-weight:bold;letter-spacing:2px;text-transform:uppercase\">One quick check</p><h1 style=\"margin:0 0 16px;font-family:Georgia,serif;font-size:32px;line-height:1.15\">Verify your email</h1><p style=\"margin:0 0 20px;color:#ddd0e6;line-height:1.6\">Hello lordfunion. Confirm this address to save progress and use account features.</p><p style=\"margin:24px 0;text-align:center\"><a href=\"https://purpleparlor.lordfunion.dev/verify-email/c32eeb4a1f6167dd569f18a36cea08e021252adcd3187c7be2334b210b27315e\" style=\"display:inline-block;border-radius:999px;background:#e8b85d;color:#241207;font-weight:bold;padding:13px 24px;text-decoration:none\">Verify email</a></p><p style=\"margin:0;color:#ac9ab8;font-size:13px;line-height:1.5\">This link expires in 24 hours. If you did not create an account, ignore this message. Never forward this link.</p>\n</td></tr><tr><td style=\"padding:20px 12px;color:#bba7c5;font-size:12px;line-height:1.6;text-align:center\"><p style=\"margin:0 0 8px\"><strong style=\"color:#ffe2a0\">Play-money only.</strong> Virtual currency has no cash value and cannot be purchased, transferred, redeemed, withdrawn, or exchanged for anything of value.</p><p style=\"margin:0\">No real-money wagering or cash prizes. Need help? <a href=\"mailto:support@lordfunion.dev\" style=\"color:#d9b8ef\">support@lordfunion.dev</a></p></td></tr></table></td></tr></table></body></html>\n','Verify your Purple Parlor email within 24 hours:\nhttps://purpleparlor.lordfunion.dev/verify-email/c32eeb4a1f6167dd569f18a36cea08e021252adcd3187c7be2334b210b27315e\nIf you did not create this account, ignore this message.','[]','sent','1','2026-07-14 16:59:21',NULL,'2026-07-14 17:00:16',NULL,'2026-07-14 16:59:21');

DROP TABLE IF EXISTS `email_verifications`;
CREATE TABLE `email_verifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `new_email` varchar(254) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `email_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `email_verifications` (`id`,`user_id`,`token_hash`,`new_email`,`expires_at`,`used_at`,`created_at`) VALUES ('9','10','dfa8b83be7dd7fc4d3c34349739b3ab678b500fe733c182ff3a44fe03a151841',NULL,'2026-07-15 16:59:21','2026-07-14 17:02:20','2026-07-14 16:59:21');

DROP TABLE IF EXISTS `game_configurations`;
CREATE TABLE `game_configurations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `game_id` bigint(20) unsigned NOT NULL,
  `version` int(11) NOT NULL,
  `configuration_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`configuration_json`)),
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_id` (`game_id`,`version`),
  CONSTRAINT `game_configurations_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game_definitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `game_definitions`;
CREATE TABLE `game_definitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(64) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `configuration_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration_json`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('1','plinko','Parlor Plinko','arcade','1','{\"slug\":\"plinko\",\"name\":\"Parlor Plinko\",\"category\":\"arcade\",\"engine\":\"instant\",\"description\":\"Drop a token through 8–16 server-generated left/right bounces into a disclosed multiplier bin.\",\"rules\":[\"Choose 8–16 rows and low, medium, or high variance.\",\"Each peg has an independent 1/2 left and 1/2 right chance.\",\"The landing bin determines the gross fictional return.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"low\":\"0.52x–2.82x\",\"medium\":\"0.28x–5.64x\",\"high\":\"0.08x–14.10x\"},\"probability\":{\"peg\":{\"left\":0.5,\"right\":0.5},\"distribution\":\"Binomial by selected row count\"},\"theoretical_rtp\":0.94,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"rows\":{\"type\":\"integer\",\"minimum\":8,\"maximum\":16,\"default\":12},\"risk\":{\"enum\":[\"low\",\"medium\",\"high\"],\"default\":\"medium\"}}},\"settings\":{\"rows\":{\"type\":\"integer\",\"minimum\":8,\"maximum\":16,\"default\":12},\"risk\":{\"enum\":[\"low\",\"medium\",\"high\"],\"default\":\"medium\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.94},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('2','classic-three-reel-slots','Royal Onion Reels','slots','1','{\"slug\":\"classic-three-reel-slots\",\"name\":\"Royal Onion Reels\",\"category\":\"slots\",\"engine\":\"instant\",\"description\":\"An original three-reel, one-payline slot featuring onions, books, lavender, crowns, and hearth symbols.\",\"rules\":[\"All three center symbols must match.\",\"Every reel uses the same disclosed 15-stop strip.\",\"A win pays the listed gross multiplier.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"onion\":\"8x\",\"lavender\":\"14x\",\"book\":\"22x\",\"fireplace\":\"33x\",\"crown\":\"55x\",\"seven\":\"136x\"},\"probability\":{\"reelStops\":15,\"threeOfAKindOnly\":true,\"hitRate\":0.056},\"theoretical_rtp\":0.9508,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"theme\":{\"enum\":[\"royal_onion\",\"cozy_fireplace\"],\"default\":\"royal_onion\"}}},\"settings\":{\"theme\":{\"enum\":[\"royal_onion\",\"cozy_fireplace\"],\"default\":\"royal_onion\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9508},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('3','five-reel-video-slots','Moonlit Library Reels','slots','1','{\"slug\":\"five-reel-video-slots\",\"name\":\"Moonlit Library Reels\",\"category\":\"slots\",\"engine\":\"instant\",\"description\":\"Five original reels form three rows and five fixed, equal-cost paylines with wild and scatter symbols.\",\"rules\":[\"Five fixed lines each receive one fifth of the wager.\",\"Wins count matching symbols left-to-right; wild substitutes except for scatter.\",\"Three or more scatters award a separate prize.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"line symbols\":\"1.398x–104.85x by symbol and length\",\"3 scatters\":\"13.98x\",\"4 scatters\":\"69.9x\",\"5+ scatters\":\"349.5x\"},\"probability\":{\"symbolWeights\":[25,22,18,14,10,6,3,2],\"paylines\":5},\"theoretical_rtp\":0.948,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"theme\":{\"enum\":[\"purple_parlor\",\"moonlit_library\",\"pixel_kingdom\"],\"default\":\"moonlit_library\"}}},\"settings\":{\"theme\":{\"enum\":[\"purple_parlor\",\"moonlit_library\",\"pixel_kingdom\"],\"default\":\"moonlit_library\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.948},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('4','blackjack','Velvet Blackjack','table','1','{\"slug\":\"blackjack\",\"name\":\"Velvet Blackjack\",\"category\":\"table\",\"engine\":\"card\",\"description\":\"Single-hand blackjack with dealer stand on all 17s and a server-shuffled 52-card deck.\",\"rules\":[\"Aces count as 1 or 11; faces count as 10.\",\"Hit or stand; the dealer draws to 17 and stands on soft 17.\",\"Natural blackjack returns 2.5x gross, ordinary win 2x, tie 1x.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"blackjack\":\"2.5x\",\"win\":\"2x\",\"push\":\"1x\",\"loss/bust\":\"0x\"},\"probability\":{\"naturalBlackjack\":0.0483,\"deck\":\"One 52-card deck shuffled every round\",\"strategyDependent\":true,\"simpleHitTo17Estimate\":0.94},\"theoretical_rtp\":0.94,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"dealerRule\":{\"const\":\"stand_soft_17\"}}},\"settings\":{\"dealerRule\":{\"const\":\"stand_soft_17\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.94},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('5','european-roulette','European Velvet Wheel','wheel','1','{\"slug\":\"european-roulette\",\"name\":\"European Velvet Wheel\",\"category\":\"wheel\",\"engine\":\"instant\",\"description\":\"A 37-pocket single-zero wheel with straight, color, parity, range, and dozen wagers.\",\"rules\":[\"One of 0–36 is selected uniformly on the server.\",\"Zero loses all even-money and dozen wagers.\",\"Gross returns include the original fictional wager.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"straight\":\"36x\",\"red/black, odd/even, low/high\":\"2x\",\"dozen\":\"3x\"},\"probability\":{\"pockets\":37,\"straight\":\"1/37\",\"evenMoney\":\"18/37\",\"dozen\":\"12/37\"},\"theoretical_rtp\":0.973,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"bet\":{\"enum\":[\"straight\",\"red\",\"black\",\"odd\",\"even\",\"low\",\"high\",\"dozen1\",\"dozen2\",\"dozen3\"]}}},\"settings\":{\"bet\":{\"enum\":[\"straight\",\"red\",\"black\",\"odd\",\"even\",\"low\",\"high\",\"dozen1\",\"dozen2\",\"dozen3\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.973},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('6','american-roulette','American Plum Wheel','wheel','1','{\"slug\":\"american-roulette\",\"name\":\"American Plum Wheel\",\"category\":\"wheel\",\"engine\":\"instant\",\"description\":\"A 38-pocket 0/00 wheel with the standard generic roulette wager families.\",\"rules\":[\"One of 0, 00, and 1–36 is selected uniformly.\",\"Both green pockets lose outside wagers.\",\"This double-zero variant has a lower theoretical return than the European wheel.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"straight\":\"36x\",\"red/black, odd/even, low/high\":\"2x\",\"dozen\":\"3x\"},\"probability\":{\"pockets\":38,\"straight\":\"1/38\",\"evenMoney\":\"18/38\",\"dozen\":\"12/38\"},\"theoretical_rtp\":0.9474,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"bet\":{\"enum\":[\"straight\",\"red\",\"black\",\"odd\",\"even\",\"low\",\"high\",\"dozen1\",\"dozen2\",\"dozen3\"]}}},\"settings\":{\"bet\":{\"enum\":[\"straight\",\"red\",\"black\",\"odd\",\"even\",\"low\",\"high\",\"dozen1\",\"dozen2\",\"dozen3\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9474},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('7','baccarat','Parlor Baccarat','table','1','{\"slug\":\"baccarat\",\"name\":\"Parlor Baccarat\",\"category\":\"table\",\"engine\":\"instant\",\"description\":\"Punto banco using the fixed third-card table; choose Player, Banker, or Tie before the deal.\",\"rules\":[\"Card totals use the final digit only.\",\"Naturals 8 or 9 stand; otherwise the standard third-card table is automatic.\",\"Banker wins return 1.95x gross, Player 2x, Tie 9x.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"player\":\"2x\",\"banker\":\"1.95x\",\"tie\":\"9x\"},\"probability\":{\"playerWin\":0.4462,\"bankerWin\":0.4586,\"tie\":0.0952},\"theoretical_rtp\":0.9876,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"bet\":{\"enum\":[\"player\",\"banker\",\"tie\"],\"default\":\"player\"}}},\"settings\":{\"bet\":{\"enum\":[\"player\",\"banker\",\"tie\"],\"default\":\"player\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9876},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('8','craps','Cozy Pass Line','dice','1','{\"slug\":\"craps\",\"name\":\"Cozy Pass Line\",\"category\":\"dice\",\"engine\":\"stateful\",\"description\":\"A focused Pass Line craps round with a preserved server-side point state.\",\"rules\":[\"Come-out 7 or 11 wins; 2, 3, or 12 loses.\",\"Any other total becomes the point.\",\"Roll the point again before 7 to win.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"pass win\":\"2x\",\"loss\":\"0x\"},\"probability\":{\"comeOutNatural\":\"8/36\",\"comeOutCraps\":\"4/36\",\"houseEdge\":0.01414},\"theoretical_rtp\":0.9859,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"bet\":{\"const\":\"pass_line\"}}},\"settings\":{\"bet\":{\"const\":\"pass_line\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9859},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('9','video-poker','Parlor Draw Poker','video_poker','1','{\"slug\":\"video-poker\",\"name\":\"Parlor Draw Poker\",\"category\":\"video_poker\",\"engine\":\"card\",\"description\":\"Five-card draw video poker with Jacks or Better, Deuces Wild, and Bonus Poker practice paytables.\",\"rules\":[\"Deal five, hold any cards, then draw once.\",\"The selected variant paytable determines the gross fictional return.\",\"Outcomes do not change based on membership or bot behavior.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"Jacks or Better\":\"1x pair through 800x royal\",\"Deuces Wild\":\"wild-deuce schedule\",\"Bonus Poker\":\"enhanced four-of-a-kind awards\"},\"probability\":{\"royalFlushNatural\":\"1/649,740\",\"strategyDependent\":true},\"theoretical_rtp\":0.9954,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"variant\":{\"enum\":[\"jacks_or_better\",\"deuces_wild\",\"bonus_poker\"],\"default\":\"jacks_or_better\"}}},\"settings\":{\"variant\":{\"enum\":[\"jacks_or_better\",\"deuces_wild\",\"bonus_poker\"],\"default\":\"jacks_or_better\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9954},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('10','texas-holdem','Parlor Hold’em Practice','poker','1','{\"slug\":\"texas-holdem\",\"name\":\"Parlor Hold’em Practice\",\"category\":\"poker\",\"engine\":\"card\",\"description\":\"Heads-up community-card poker against a clearly labeled computer opponent.\",\"rules\":[\"Two private cards and a shared five-card board form the best five-card hand.\",\"Check to reveal turn and river or fold.\",\"The computer has no access to future cards; Friendly reveals one hole card, Regular gives a broad made-hand hint, and Sharp gives neither.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"win\":\"2x\",\"split pot\":\"1x\",\"fold/loss\":\"0x\"},\"probability\":{\"deck\":\"52 cards without replacement\",\"showdown\":\"standard best-five-of-seven ranking\"},\"theoretical_rtp\":1,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"difficulty\":{\"enum\":[\"friendly\",\"regular\",\"sharp\"],\"default\":\"friendly\"}}},\"settings\":{\"difficulty\":{\"enum\":[\"friendly\",\"regular\",\"sharp\"],\"default\":\"friendly\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":1},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('11','three-card-poker','Three Card Parlor','poker','1','{\"slug\":\"three-card-poker\",\"name\":\"Three Card Parlor\",\"category\":\"poker\",\"engine\":\"instant\",\"description\":\"A streamlined three-card ante practice round using Trail, Pure Sequence, Sequence, Color, Pair, and High Card rankings.\",\"rules\":[\"Choose play or fold before the deal.\",\"Dealer qualifies with Queen-high or better.\",\"Player win and qualifying bonuses follow the disclosed table.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"dealer not qualified\":\"1.5x\",\"ordinary win\":\"2x\",\"Trail/Pure Sequence bonus\":\"additional 1x–4x\"},\"probability\":{\"dealerQualification\":\"Queen-high or pair+\",\"deck\":\"52 cards\"},\"theoretical_rtp\":0.99,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"decision\":{\"enum\":[\"play\",\"fold\"],\"default\":\"play\"}}},\"settings\":{\"decision\":{\"enum\":[\"play\",\"fold\"],\"default\":\"play\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.99},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('12','caribbean-stud','Island Hearth Stud','poker','1','{\"slug\":\"caribbean-stud\",\"name\":\"Island Hearth Stud\",\"category\":\"poker\",\"engine\":\"card\",\"description\":\"Five-card stud against the house with one dealer up-card and a generic qualifying rule.\",\"rules\":[\"Review five cards and choose raise or fold.\",\"Dealer qualifies with Ace-King high or a pair.\",\"A qualifying player win receives the disclosed hand bonus.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"dealer not qualified\":\"1x\",\"qualifying win\":\"1.9x plus half of the 1x–51x hand bonus\",\"push\":\"1x\"},\"probability\":{\"dealerQualification\":\"Ace-King high or better\",\"strategyDependent\":true,\"defaultRaisePolicyEstimate\":0.84},\"theoretical_rtp\":0.84,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"decision\":{\"enum\":[\"raise\",\"fold\"]}}},\"settings\":{\"decision\":{\"enum\":[\"raise\",\"fold\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.84},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('13','casino-war','Velvet Card War','card','1','{\"slug\":\"casino-war\",\"name\":\"Velvet Card War\",\"category\":\"card\",\"engine\":\"card\",\"description\":\"One high-card showdown; matching ranks offer a server-preserved War or surrender choice.\",\"rules\":[\"Higher rank wins.\",\"After a tie, surrender returns half or War burns three and compares again.\",\"A tie during War favors the player in this practice ruleset.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"ordinary win\":\"2x\",\"war win\":\"1x because no additional stake is charged\",\"surrender\":\"0.5x\",\"loss\":\"0x\"},\"probability\":{\"initialTie\":\"1/13\",\"ordinaryComparisonSymmetric\":true},\"theoretical_rtp\":0.972,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"tieChoice\":{\"enum\":[\"war\",\"surrender\"]}}},\"settings\":{\"tieChoice\":{\"enum\":[\"war\",\"surrender\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.972},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('14','red-dog','Red Dog Practice','card','1','{\"slug\":\"red-dog\",\"name\":\"Red Dog Practice\",\"category\":\"card\",\"engine\":\"card\",\"description\":\"Two ranked cards establish a spread; a third card wins when its rank lands strictly between them.\",\"rules\":[\"Same-rank or consecutive cards push immediately.\",\"Otherwise draw one third card.\",\"Smaller spreads award larger disclosed returns.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"pair match\":\"12x; otherwise pair pushes\",\"spread 1\":\"6x\",\"spread 2\":\"5x\",\"spread 3\":\"3x\",\"spread 4–11\":\"2x\"},\"probability\":{\"deck\":\"52 cards without replacement\",\"conditionalWin\":\"four times the spread / 50 remaining cards\"},\"theoretical_rtp\":0.9081,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9081},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('15','let-it-ride','Let the Velvet Ride','poker','1','{\"slug\":\"let-it-ride\",\"name\":\"Let the Velvet Ride\",\"category\":\"poker\",\"engine\":\"card\",\"description\":\"A five-card poker practice variant with three initial units and two ride-or-pull decisions.\",\"rules\":[\"Three player cards combine with two community cards.\",\"At each reveal, ride or pull one unit.\",\"Tens-or-better and stronger hands use the disclosed schedule.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"tens or better\":\"1:1 profit per riding unit\",\"two pair\":\"2:1\",\"trips\":\"3:1\",\"straight\":\"5:1\",\"flush\":\"8:1\",\"full house\":\"11:1\",\"quads+\":\"50:1–1000:1\"},\"probability\":{\"fiveCardPoker\":true,\"decisionStages\":2,\"strategyDependent\":true},\"theoretical_rtp\":0.967,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.967},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('16','pai-gow-poker','Two-Hand Pai Gow Practice','poker','1','{\"slug\":\"pai-gow-poker\",\"name\":\"Two-Hand Pai Gow Practice\",\"category\":\"poker\",\"engine\":\"instant\",\"description\":\"Seven cards are automatically arranged into a five-card high hand and two-card low hand using a disclosed house-way approximation.\",\"rules\":[\"The high hand must outrank the low hand.\",\"Win both comparisons to win; lose both to lose; split comparisons push.\",\"The same deterministic arrangement method is used for player and dealer.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"win both\":\"1.95x\",\"split\":\"1x\",\"lose both\":\"0x\"},\"probability\":{\"pushFrequency\":\"High because split comparisons push\",\"commission\":\"5% of gross even-money win\"},\"theoretical_rtp\":0.985,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.985},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('17','hi-lo','Single-Card Hi-Lo','card','1','{\"slug\":\"hi-lo\",\"name\":\"Single-Card Hi-Lo\",\"category\":\"card\",\"engine\":\"card\",\"description\":\"Guess whether the next server-dealt rank is higher or lower than the visible card.\",\"rules\":[\"Suits do not matter.\",\"A correct strict guess returns 1.9x.\",\"Equal ranks push and return 1x.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"correct\":\"Probability-adjusted gross return shown before the guess\",\"equal rank\":\"1x\",\"incorrect\":\"0x\"},\"probability\":{\"tie\":\"3/51 after first card\",\"0\":\"higher/lower depends on visible rank\",\"targetReturn\":0.95},\"theoretical_rtp\":0.95,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.95},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('18','five-card-draw','Five Card Draw Bots','poker','1','{\"slug\":\"five-card-draw\",\"name\":\"Five Card Draw Bots\",\"category\":\"poker\",\"engine\":\"card\",\"description\":\"Classic five-card draw against a transparent rule-based computer opponent.\",\"rules\":[\"Hold any cards and draw once.\",\"Friendly keeps made pairs only; Regular also keeps its highest card; Sharp also recognizes four-card flush draws.\",\"Standard poker ranking determines the showdown; every opponent is explicitly computer-controlled.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"win\":\"2x\",\"push\":\"1x\",\"loss\":\"0x\"},\"probability\":{\"deck\":\"52 cards without replacement\",\"bot\":\"Rule-based, not human\"},\"theoretical_rtp\":1,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"difficulty\":{\"enum\":[\"friendly\",\"regular\",\"sharp\"],\"default\":\"regular\"}}},\"settings\":{\"difficulty\":{\"enum\":[\"friendly\",\"regular\",\"sharp\"],\"default\":\"regular\"}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":1},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('19','teen-patti-practice','Three-Card Patti Practice','poker','1','{\"slug\":\"teen-patti-practice\",\"name\":\"Three-Card Patti Practice\",\"category\":\"poker\",\"engine\":\"instant\",\"description\":\"A clearly labeled practice comparison inspired by the common three-card Trail-to-High-Card ranking family.\",\"rules\":[\"Each side receives three cards.\",\"Rank order is Trail, Pure Sequence, Sequence, Color, Pair, High Card.\",\"There is no real-money play and no social betting round.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"win\":\"1.95x\",\"tie\":\"1x\",\"loss\":\"0x\"},\"probability\":{\"symmetricDeal\":true,\"deck\":\"52 cards\"},\"theoretical_rtp\":0.975,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.975},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('20','parlor-switch','Parlor Hand Switch','table','1','{\"slug\":\"parlor-switch\",\"name\":\"Parlor Hand Switch\",\"category\":\"table\",\"engine\":\"card\",\"description\":\"Original two-hand blackjack-inspired practice: optionally swap the second cards, then both hands and dealer auto-play to 17.\",\"rules\":[\"Receive two two-card hands.\",\"Switch the second cards or keep them.\",\"Both hands auto-hit below 17; dealer 22 pushes surviving hands.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"per-hand win\":\"2x share\",\"per-hand push/dealer 22\":\"1x share\",\"loss\":\"0x\"},\"probability\":{\"twoHands\":true,\"dealer22Push\":true,\"strategyDependent\":true},\"theoretical_rtp\":0.905,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.905},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('21','sic-bo','Parlor Sic Bo','dice','1','{\"slug\":\"sic-bo\",\"name\":\"Parlor Sic Bo\",\"category\":\"dice\",\"engine\":\"instant\",\"description\":\"Three dice support Small, Big, Odd, Even, specific Sum, and specific Triple wagers.\",\"rules\":[\"Triples lose Small, Big, Odd, and Even.\",\"Sum and triple returns vary by rarity.\",\"All three dice are generated independently on the server.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"small/big/odd/even\":\"2x\",\"sum\":\"6x–61x\",\"specific triple\":\"181x\"},\"probability\":{\"outcomes\":216,\"smallOrBigWin\":\"105/216\"},\"theoretical_rtp\":0.9722,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"bet\":{\"enum\":[\"small\",\"big\",\"odd\",\"even\",\"sum\",\"triple\"]}}},\"settings\":{\"bet\":{\"enum\":[\"small\",\"big\",\"odd\",\"even\",\"sum\",\"triple\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9722},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('22','keno','Lavender Keno','numbers','1','{\"slug\":\"keno\",\"name\":\"Lavender Keno\",\"category\":\"numbers\",\"engine\":\"instant\",\"description\":\"Pick 1–10 unique numbers from 1–80; the server draws 20 without replacement.\",\"rules\":[\"Picks must be unique.\",\"Matches are the intersection of picks and 20 drawn numbers.\",\"The paytable depends on both spots chosen and matches.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"1–10 spots\":\"See full spot/match matrix returned by rules API\",\"maximum\":\"32,800x on 10/10\"},\"probability\":{\"draw\":\"20 of 80 without replacement\",\"matchDistribution\":\"Hypergeometric\"},\"theoretical_rtp\":0.9,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"picks\":{\"type\":\"array\",\"minItems\":1,\"maxItems\":10,\"uniqueItems\":true}}},\"settings\":{\"picks\":{\"type\":\"array\",\"minItems\":1,\"maxItems\":10,\"uniqueItems\":true}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('23','bingo','Parlor 75-Ball Bingo','numbers','1','{\"slug\":\"bingo\",\"name\":\"Parlor 75-Ball Bingo\",\"category\":\"numbers\",\"engine\":\"instant\",\"description\":\"A server-generated 5×5 card with a free center and 30 unique calls; completed rows, columns, and diagonals pay.\",\"rules\":[\"B/I/N/G/O columns use their standard 15-number ranges.\",\"The center space is free.\",\"Twelve possible lines are checked after 30 calls.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"1 line\":\"4.44x\",\"2 lines\":\"22.2x\",\"3+ lines\":\"111x\"},\"probability\":{\"calls\":\"30 of 75 without replacement\",\"linesChecked\":12},\"theoretical_rtp\":0.92,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.92},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('24','mines','Moonlit Mines','arcade','1','{\"slug\":\"mines\",\"name\":\"Moonlit Mines\",\"category\":\"arcade\",\"engine\":\"stateful\",\"description\":\"Reveal safe tiles on a 5×5 board and cash out before uncovering one of 1–10 hidden mines.\",\"rules\":[\"Mine locations are generated and stored only on the server.\",\"Each safe reveal raises a probability-based multiplier.\",\"Cash out after at least one safe tile; a mine returns zero.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"safe cashout\":\"97% divided by cumulative survival probability\",\"mine\":\"0x\"},\"probability\":{\"board\":25,\"mineRange\":[1,10],\"edge\":0.03},\"theoretical_rtp\":0.97,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"mines\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":10,\"default\":5}}},\"settings\":{\"mines\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":10,\"default\":5}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.97},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('25','over-under-dice','Over/Under D100','dice','1','{\"slug\":\"over-under-dice\",\"name\":\"Over/Under D100\",\"category\":\"dice\",\"engine\":\"instant\",\"description\":\"Choose over or under a threshold from 2–98, then compare a uniform 0.00–99.99 server roll.\",\"rules\":[\"Under wins strictly below the target; Over wins at or above it.\",\"The multiplier automatically reflects the selected probability.\",\"A fixed 2% mathematical margin is disclosed.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"win\":\"0.98 divided by win probability\",\"loss\":\"0x\"},\"probability\":{\"rolls\":10000,\"uniform\":true,\"edge\":0.02},\"theoretical_rtp\":0.98,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"target\":{\"type\":\"integer\",\"minimum\":2,\"maximum\":98,\"default\":50},\"choice\":{\"enum\":[\"under\",\"over\"]}}},\"settings\":{\"target\":{\"type\":\"integer\",\"minimum\":2,\"maximum\":98,\"default\":50},\"choice\":{\"enum\":[\"under\",\"over\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.98},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('26','coin-flip','Golden Coin Flip','arcade','1','{\"slug\":\"coin-flip\",\"name\":\"Golden Coin Flip\",\"category\":\"arcade\",\"engine\":\"instant\",\"description\":\"Choose heads or tails for a cryptographically generated equal-probability flip.\",\"rules\":[\"Heads and tails each have exactly one of two integer outcomes.\",\"A correct guess returns 1.98x gross.\",\"Past flips do not influence future flips.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"correct\":\"1.98x\",\"incorrect\":\"0x\"},\"probability\":{\"heads\":0.5,\"tails\":0.5},\"theoretical_rtp\":0.99,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"guess\":{\"enum\":[\"heads\",\"tails\"]}}},\"settings\":{\"guess\":{\"enum\":[\"heads\",\"tails\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.99},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('27','prize-wheel','Cozy Prize Wheel','wheel','1','{\"slug\":\"prize-wheel\",\"name\":\"Cozy Prize Wheel\",\"category\":\"wheel\",\"engine\":\"instant\",\"description\":\"A 16-segment uniform wheel with every segment and gross multiplier disclosed.\",\"rules\":[\"Every segment is equally likely.\",\"The pointer index comes only from the server result.\",\"Zero segments return no fictional coins.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"segments\":[\"0x\",\"0.25x\",\"0.75x\",\"0.75x\",\"1x\",\"1.5x\",\"0x\",\"2x\",\"0.25x\",\"0.75x\",\"0x\",\"2.5x\",\"0.5x\",\"1x\",\"0x\",\"4x\"]},\"probability\":{\"segments\":16,\"each\":\"1/16\"},\"theoretical_rtp\":0.9531,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.9531},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('28','number-draw','Parlor Number Draw','numbers','1','{\"slug\":\"number-draw\",\"name\":\"Parlor Number Draw\",\"category\":\"numbers\",\"engine\":\"instant\",\"description\":\"Guess a uniform two-digit number, its last digit, or its ten-number band.\",\"rules\":[\"Exact mode compares 0–99.\",\"Last-digit and range modes each cover ten outcomes.\",\"All modes target a 95% long-run return.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"exact\":\"95x\",\"last digit\":\"9.5x\",\"range\":\"9.5x\"},\"probability\":{\"exact\":\"1/100\",\"lastDigit\":\"1/10\",\"range\":\"1/10\"},\"theoretical_rtp\":0.95,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"mode\":{\"enum\":[\"exact\",\"last_digit\",\"range\"]}}},\"settings\":{\"mode\":{\"enum\":[\"exact\",\"last_digit\",\"range\"]}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.95},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('29','pachinko','Lavender Pachinko','arcade','1','{\"slug\":\"pachinko\",\"name\":\"Lavender Pachinko\",\"category\":\"arcade\",\"engine\":\"instant\",\"description\":\"A 15-pin server-generated left/right path lands in one of 16 symmetric prize slots.\",\"rules\":[\"Each pin sends the ball left or right with equal probability.\",\"Slot probability follows the 15-row binomial distribution.\",\"The complete path is returned for animation.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"outer to center slots\":\"50x, 20x, 8x, 4x, 2x, 1.2x, 0.7x, 0.43x\"},\"probability\":{\"pins\":15,\"pathCount\":32768,\"distribution\":\"Binomial\"},\"theoretical_rtp\":0.952,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.952},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('30','horse-racing','Velvet Downs','simulation','1','{\"slug\":\"horse-racing\",\"name\":\"Velvet Downs\",\"category\":\"simulation\",\"engine\":\"instant\",\"description\":\"Choose one of six fictional horses with disclosed weights; the server selects the winner and animates a cosmetic finish order.\",\"rules\":[\"Horse names and odds are fictional.\",\"Winner weights are 25, 22, 19, 15, 11, and 8 out of 100.\",\"Gross return equals 95% divided by the selected win probability.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"Lavender Bolt\":\"3.8x\",\"Golden Onion\":\"4.31x\",\"Velvet Comet\":\"5x\",\"Cozy Ember\":\"6.33x\",\"Moonlit Crown\":\"8.63x\",\"Royal Whisker\":\"11.87x\"},\"probability\":{\"weights\":[25,22,19,15,11,8]},\"theoretical_rtp\":0.95,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"horse\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":5}}},\"settings\":{\"horse\":{\"type\":\"integer\",\"minimum\":0,\"maximum\":5}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.95},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('31','scratch-cards','Free Parlor Scratch','casual','1','{\"slug\":\"scratch-cards\",\"name\":\"Free Parlor Scratch\",\"category\":\"casual\",\"engine\":\"instant\",\"description\":\"A wager-free nine-panel matching card that awards practice score only, never wagerable currency.\",\"rules\":[\"Scratch/reveal all nine panels.\",\"Three or more identical symbols award practice score.\",\"There is no Cozy Coin wager or payout.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":0,\"maximum\":0,\"increment\":0,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[0],\"paytable\":{\"3 matches\":\"10 practice points\",\"4 matches\":\"40 practice points\",\"5+ matches\":\"100 practice points\"},\"probability\":{\"sixSymbols\":true,\"panels\":9},\"theoretical_rtp\":null,\"rtp_method\":\"Not applicable: this is a wager-free practice game.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":false,\"defaultAction\":\"play\",\"expectedRtp\":null},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('32','memory-match','Fireside Memory Match','casual','1','{\"slug\":\"memory-match\",\"name\":\"Fireside Memory Match\",\"category\":\"casual\",\"engine\":\"stateful\",\"description\":\"A wager-free 16-card memory board with eight server-shuffled pairs.\",\"rules\":[\"Flip two different face-down cards.\",\"Matching pairs stay visible; mismatches turn back over.\",\"Clear all eight pairs with as few moves as possible.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":0,\"maximum\":0,\"increment\":0,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[0],\"paytable\":{\"completion\":\"Practice score only; no virtual-currency payout\"},\"probability\":{\"pairs\":8,\"cards\":16},\"theoretical_rtp\":null,\"rtp_method\":\"Not applicable: this is a wager-free practice game.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":false,\"defaultAction\":\"play\",\"expectedRtp\":null},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('33','klondike-solitaire','Velvet Klondike','solitaire','1','{\"slug\":\"klondike-solitaire\",\"name\":\"Velvet Klondike\",\"category\":\"solitaire\",\"engine\":\"solitaire\",\"description\":\"Wager-free Klondike with seven tableau columns, stock, waste, and four suit foundations.\",\"rules\":[\"Build tableau downward in alternating colors.\",\"Only Kings enter empty tableau columns.\",\"Build each foundation from Ace through King.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":0,\"maximum\":0,\"increment\":0,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[0],\"paytable\":{\"completion\":\"Practice achievement only\"},\"probability\":{\"deck\":52,\"tableauColumns\":7},\"theoretical_rtp\":null,\"rtp_method\":\"Not applicable: this is a wager-free practice game.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":false,\"defaultAction\":\"play\",\"expectedRtp\":null},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('34','pyramid-solitaire','Royal Pyramid','solitaire','1','{\"slug\":\"pyramid-solitaire\",\"name\":\"Royal Pyramid\",\"category\":\"solitaire\",\"engine\":\"solitaire\",\"description\":\"Wager-free Pyramid solitaire with a 28-card tableau and stock/waste pair removal.\",\"rules\":[\"Only uncovered cards may be selected.\",\"Remove a King alone or two cards totaling 13.\",\"Clear all 28 tableau cards to win.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":0,\"maximum\":0,\"increment\":0,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[0],\"paytable\":{\"completion\":\"Practice achievement only\"},\"probability\":{\"tableauCards\":28,\"targetSum\":13},\"theoretical_rtp\":null,\"rtp_method\":\"Not applicable: this is a wager-free practice game.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":false,\"defaultAction\":\"play\",\"expectedRtp\":null},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('35','tripeaks-solitaire','Moonlit TriPeaks','solitaire','1','{\"slug\":\"tripeaks-solitaire\",\"name\":\"Moonlit TriPeaks\",\"category\":\"solitaire\",\"engine\":\"solitaire\",\"description\":\"Wager-free TriPeaks with 28 tableau cards, a stock, and rank-adjacent clearing.\",\"rules\":[\"Only uncovered tableau cards may be taken.\",\"Take a rank one above or below the waste top; Ace wraps with King.\",\"Clear all three peaks to win.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":0,\"maximum\":0,\"increment\":0,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[0],\"paytable\":{\"completion\":\"Practice achievement only\"},\"probability\":{\"tableauCards\":28,\"aceKingWrap\":true},\"theoretical_rtp\":null,\"rtp_method\":\"Not applicable: this is a wager-free practice game.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":false,\"defaultAction\":\"play\",\"expectedRtp\":null},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('36','freecell','Parlor FreeCell','solitaire','1','{\"slug\":\"freecell\",\"name\":\"Parlor FreeCell\",\"category\":\"solitaire\",\"engine\":\"solitaire\",\"description\":\"Wager-free FreeCell with eight visible columns, four free cells, and four suit foundations.\",\"rules\":[\"Move one exposed card per action.\",\"Columns build downward in alternating colors.\",\"Free cells hold one card; foundations build Ace through King.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":0,\"maximum\":0,\"increment\":0,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[0],\"paytable\":{\"completion\":\"Practice achievement only\"},\"probability\":{\"columns\":8,\"freeCells\":4,\"openInformation\":true},\"theoretical_rtp\":null,\"rtp_method\":\"Not applicable: this is a wager-free practice game.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":false,\"defaultAction\":\"play\",\"expectedRtp\":null},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('37','higher-lower-streak','Crown Streak','card','1','{\"slug\":\"higher-lower-streak\",\"name\":\"Crown Streak\",\"category\":\"card\",\"engine\":\"stateful\",\"description\":\"Build a streak by guessing higher or lower, then cash out a rising disclosed multiplier.\",\"rules\":[\"Equal ranks safely continue the streak.\",\"A wrong strict guess ends the round.\",\"Cash out after at least one successful guess.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"cashout\":\"0.95 divided by the cumulative disclosed survival probability, capped at 500x\",\"wrong guess\":\"0x\"},\"probability\":{\"deck\":\"52 cards without replacement\",\"strategyDependent\":true},\"theoretical_rtp\":0.95,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.95},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('38','gem-drop','Amethyst Gem Drop','arcade','1','{\"slug\":\"gem-drop\",\"name\":\"Amethyst Gem Drop\",\"category\":\"arcade\",\"engine\":\"instant\",\"description\":\"A server-generated 6×6 gem board pays horizontal runs of three or more identical gems.\",\"rules\":[\"Five gem types are equally likely per cell.\",\"Each row is scanned left-to-right for non-overlapping runs.\",\"Longer runs add larger gross returns.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"3 run\":\"0.965x\",\"4 run\":\"1.93x\",\"5 run\":\"2.895x\",\"6 run\":\"3.86x\"},\"probability\":{\"cells\":36,\"symbols\":5,\"independentCells\":true},\"theoretical_rtp\":0.93,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.93},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('39','lucky-cups','Lucky Lavender Cups','arcade','1','{\"slug\":\"lucky-cups\",\"name\":\"Lucky Lavender Cups\",\"category\":\"arcade\",\"engine\":\"instant\",\"description\":\"Pick one of three cups; a server-selected cup hides the golden onion.\",\"rules\":[\"Each cup is equally likely.\",\"The shuffle order is cosmetic and cannot change the winning cup.\",\"A correct pick returns 2.85x gross.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"correct\":\"2.85x\",\"incorrect\":\"0x\"},\"probability\":{\"cups\":3,\"each\":\"1/3\"},\"theoretical_rtp\":0.95,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":{\"cup\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":3}}},\"settings\":{\"cup\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":3}},\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.95},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `game_definitions` (`id`,`slug`,`name`,`category`,`active`,`configuration_json`,`created_at`,`updated_at`) VALUES ('40','treasure-tiles','Treasure Tiles','arcade','1','{\"slug\":\"treasure-tiles\",\"name\":\"Treasure Tiles\",\"category\":\"arcade\",\"engine\":\"stateful\",\"description\":\"Explore a 20-tile server-hidden map containing three traps and ten treasures, then bank the accumulated fictional return.\",\"rules\":[\"Trap and treasure positions remain server-only until completion.\",\"Empty tiles are safe; treasure raises the cashout amount.\",\"Cash out after finding treasure or lose the round on a trap.\"],\"tutorial\":[\"Choose a fictional Cozy Coin wager or use Practice where available.\",\"Choose the displayed action; the PHP server generates and validates every result.\",\"Review the outcome, paytable, and recent-round summary. You may leave or take a break at any time.\"],\"wager\":{\"minimum\":1,\"maximum\":1000,\"increment\":1,\"currency\":\"cozy_coins\",\"cash_value\":false},\"wager_increments\":[1,5,10],\"paytable\":{\"cashout\":\"0.72x plus 0.17x per treasure point\",\"trap\":\"0x\"},\"probability\":{\"tiles\":20,\"traps\":3,\"treasures\":10},\"theoretical_rtp\":0.94,\"rtp_method\":\"Long-run mathematical estimate for the disclosed default rules; player choices can change realized return.\",\"configuration_schema\":{\"type\":\"object\",\"additionalProperties\":false,\"properties\":[]},\"settings\":[],\"client_renderer\":\"server-outcome-v1\",\"animation_controller\":{\"skippable\":true,\"speedOptions\":[\"instant\",\"quick\",\"cozy\"],\"reducedMotion\":true},\"sound_manifest\":{\"deal\":\"game-deal\",\"win\":\"game-win-soft\",\"loss\":\"game-loss-soft\",\"action\":\"game-action\"},\"statistics\":[\"rounds\",\"wins\",\"losses\",\"pushes\",\"fictional_wagered\",\"fictional_returned\",\"largest_fictional_win\"],\"simulation\":{\"enabled\":true,\"defaultAction\":\"play\",\"expectedRtp\":0.94},\"notices\":{\"play_money_only\":true,\"no_cash_value\":true,\"server_authoritative\":true}}','2026-07-14 13:06:04','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `game_favorites`;
CREATE TABLE `game_favorites` (
  `user_id` bigint(20) unsigned NOT NULL,
  `game_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`game_id`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `game_favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `game_favorites_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game_definitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `game_round_actions`;
CREATE TABLE `game_round_actions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `round_id` bigint(20) unsigned NOT NULL,
  `sequence_number` int(11) NOT NULL,
  `action_type` varchar(64) NOT NULL,
  `action_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`action_json`)),
  `result_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`result_json`)),
  `idempotency_key` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  UNIQUE KEY `round_id` (`round_id`,`sequence_number`),
  CONSTRAINT `game_round_actions_ibfk_1` FOREIGN KEY (`round_id`) REFERENCES `game_rounds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `game_rounds`;
CREATE TABLE `game_rounds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `game_id` bigint(20) unsigned NOT NULL,
  `public_id` varchar(64) NOT NULL,
  `status` varchar(32) NOT NULL,
  `wager_amount` bigint(20) NOT NULL,
  `payout_amount` bigint(20) DEFAULT NULL,
  `currency` varchar(32) NOT NULL,
  `client_seed` varchar(128) DEFAULT NULL,
  `server_seed_hash` varchar(64) NOT NULL,
  `server_seed_encrypted` text NOT NULL,
  `request_id` varchar(64) NOT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `started_at` datetime NOT NULL,
  `settled_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_id` (`public_id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `game_id` (`game_id`),
  KEY `idx_game_rounds_user_status` (`user_id`,`status`,`started_at`),
  CONSTRAINT `game_rounds_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `game_rounds_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game_definitions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `game_seed_commits`;
CREATE TABLE `game_seed_commits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `round_id` bigint(20) unsigned NOT NULL,
  `commit_hash` varchar(64) NOT NULL,
  `server_seed` varchar(191) DEFAULT NULL,
  `revealed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `round_id` (`round_id`),
  CONSTRAINT `game_seed_commits_ibfk_1` FOREIGN KEY (`round_id`) REFERENCES `game_rounds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `game_seed_queue`;
CREATE TABLE `game_seed_queue` (
  `owner_key` varchar(191) NOT NULL,
  `commit_hash` varchar(64) NOT NULL,
  `server_seed_encrypted` text NOT NULL,
  `version` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`owner_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `guest_conversions`;
CREATE TABLE `guest_conversions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guest_token_hash` varchar(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `converted_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guest_token_hash` (`guest_token_hash`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `guest_conversions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `guest_conversions` (`id`,`guest_token_hash`,`user_id`,`idempotency_key`,`converted_at`) VALUES ('1','3f1936e96a1edaba3b54058528aa4e0d38fa02091b033a9be3b63f2c7e2ee0c1','10','guest-conversion:ed52ae62c311096f8e7b616f13e6f9a93cde51e6b42d92679088d86a75b7ee90','2026-07-14 16:59:20');

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `provider` varchar(32) NOT NULL,
  `external_id` varchar(191) DEFAULT NULL,
  `status` varchar(32) NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `issued_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `leaderboard_entries`;
CREATE TABLE `leaderboard_entries` (
  `leaderboard_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `score` bigint(20) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`leaderboard_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `leaderboard_entries_ibfk_1` FOREIGN KEY (`leaderboard_id`) REFERENCES `leaderboards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leaderboard_entries_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `leaderboards`;
CREATE TABLE `leaderboards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `leaderboard_key` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `configuration_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`configuration_json`)),
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leaderboard_key` (`leaderboard_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `leaderboards` (`id`,`leaderboard_key`,`name`,`configuration_json`,`starts_at`,`ends_at`,`active`) VALUES ('1','fictional_achievement_points','Fictional Achievement Points','{\"metric\":\"server_recorded_fictional_points\",\"cash_value\":false,\"privacy_required\":true}',NULL,NULL,'1');

DROP TABLE IF EXISTS `legal_acceptances`;
CREATE TABLE `legal_acceptances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `document_key` varchar(100) NOT NULL,
  `document_version` varchar(32) NOT NULL,
  `ip_hash` varchar(64) DEFAULT NULL,
  `accepted_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`document_key`,`document_version`),
  CONSTRAINT `legal_acceptances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `legal_acceptances` (`id`,`user_id`,`document_key`,`document_version`,`ip_hash`,`accepted_at`) VALUES ('7','10','terms','1',NULL,'2026-07-14 16:59:20');
INSERT INTO `legal_acceptances` (`id`,`user_id`,`document_key`,`document_version`,`ip_hash`,`accepted_at`) VALUES ('8','10','privacy','1',NULL,'2026-07-14 16:59:20');
INSERT INTO `legal_acceptances` (`id`,`user_id`,`document_key`,`document_version`,`ip_hash`,`accepted_at`) VALUES ('9','10','virtual-currency','1',NULL,'2026-07-14 16:59:20');

DROP TABLE IF EXISTS `licensing_inquiries`;
CREATE TABLE `licensing_inquiries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `business_name` varchar(150) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `service_requested` varchar(100) NOT NULL,
  `budget_range` varchar(100) DEFAULT NULL,
  `message` text NOT NULL,
  `consent` tinyint(1) NOT NULL,
  `spam_score` int(11) NOT NULL DEFAULT 0,
  `status` varchar(32) NOT NULL DEFAULT 'new',
  `submitted_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email_hash` varchar(64) NOT NULL,
  `ip_hash` varchar(64) NOT NULL,
  `successful` tinyint(1) NOT NULL DEFAULT 0,
  `attempted_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_login_attempts_lookup` (`email_hash`,`ip_hash`,`attempted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `login_attempts` (`id`,`email_hash`,`ip_hash`,`successful`,`attempted_at`) VALUES ('6','3c1bb74deacdb6f15aa09fa7540eb98980e5ee3370e4524b0d22d390d81a0191','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','1','2026-07-14 17:02:26');

DROP TABLE IF EXISTS `managed_content_revisions`;
CREATE TABLE `managed_content_revisions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_type` varchar(32) NOT NULL,
  `content_key` varchar(100) NOT NULL,
  `version_label` varchar(32) NOT NULL,
  `title_text` varchar(200) NOT NULL,
  `body_text` text NOT NULL,
  `placeholders_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`placeholders_json`)),
  `status` varchar(32) NOT NULL DEFAULT 'draft',
  `based_on_revision_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `published_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `approved_at` datetime DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type` (`content_type`,`content_key`,`version_label`),
  KEY `based_on_revision_id` (`based_on_revision_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  KEY `published_by` (`published_by`),
  KEY `idx_managed_content_lookup` (`content_type`,`content_key`,`status`,`id`),
  CONSTRAINT `managed_content_revisions_ibfk_1` FOREIGN KEY (`based_on_revision_id`) REFERENCES `managed_content_revisions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `managed_content_revisions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `managed_content_revisions_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `managed_content_revisions_ibfk_4` FOREIGN KEY (`published_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `membership_plan_prices`;
CREATE TABLE `membership_plan_prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` bigint(20) unsigned NOT NULL,
  `billing_period` varchar(16) NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `provider` varchar(32) NOT NULL,
  `provider_plan_id` varchar(191) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_id` (`plan_id`,`billing_period`,`provider`,`currency`),
  CONSTRAINT `membership_plan_prices_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `membership_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `CONSTRAINT_1` CHECK (`amount_cents` >= 0)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `membership_plan_prices` (`id`,`plan_id`,`billing_period`,`amount_cents`,`currency`,`provider`,`provider_plan_id`,`active`,`created_at`,`updated_at`) VALUES ('1','2','monthly','299','USD','demo','demo_cozy_monthly','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `membership_plan_prices` (`id`,`plan_id`,`billing_period`,`amount_cents`,`currency`,`provider`,`provider_plan_id`,`active`,`created_at`,`updated_at`) VALUES ('2','2','annual','2999','USD','demo','demo_cozy_annual','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `membership_plan_prices` (`id`,`plan_id`,`billing_period`,`amount_cents`,`currency`,`provider`,`provider_plan_id`,`active`,`created_at`,`updated_at`) VALUES ('3','3','monthly','599','USD','demo','demo_plus_monthly','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `membership_plan_prices` (`id`,`plan_id`,`billing_period`,`amount_cents`,`currency`,`provider`,`provider_plan_id`,`active`,`created_at`,`updated_at`) VALUES ('4','3','annual','5999','USD','demo','demo_plus_annual','1','2026-07-14 13:06:04','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `membership_plans`;
CREATE TABLE `membership_plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `plan_key` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `benefits_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`benefits_json`)),
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_key` (`plan_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `membership_plans` (`id`,`plan_key`,`name`,`description`,`benefits_json`,`active`,`sort_order`,`created_at`,`updated_at`) VALUES ('1','free','Free','All standard games and core account features.','[]','1','0','2026-07-14 13:06:04','2026-07-14 19:02:28');
INSERT INTO `membership_plans` (`id`,`plan_key`,`name`,`description`,`benefits_json`,`active`,`sort_order`,`created_at`,`updated_at`) VALUES ('2','cozy_club','Cozy Club','Ad-free lounge membership with premium themes, statistics, profile perks, and a fixed daily Cozy Coin grant.','[\"ads.disabled\",\"theme.purple_premium\",\"theme.fireplace\",\"statistics.advanced\",\"supporter.badge\"]','1','1','2026-07-14 13:06:04','2026-07-14 19:02:28');
INSERT INTO `membership_plans` (`id`,`plan_key`,`name`,`description`,`benefits_json`,`active`,`sort_order`,`created_at`,`updated_at`) VALUES ('3','cozy_club_plus','Cozy Club Plus','Expanded lounge membership with every premium interface perk and a larger fixed daily Cozy Coin grant.','[\"ads.disabled\",\"theme.purple_premium\",\"theme.fireplace\",\"statistics.advanced\",\"statistics.export\",\"layout.expanded\",\"profile.animated_crown\",\"supporter.badge\"]','1','2','2026-07-14 13:06:04','2026-07-14 19:02:28');

DROP TABLE IF EXISTS `mission_progress`;
CREATE TABLE `mission_progress` (
  `user_id` bigint(20) unsigned NOT NULL,
  `mission_id` bigint(20) unsigned NOT NULL,
  `progress_value` int(11) NOT NULL DEFAULT 0,
  `completed_at` datetime DEFAULT NULL,
  `rewarded_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`mission_id`),
  KEY `mission_id` (`mission_id`),
  CONSTRAINT `mission_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mission_progress_ibfk_2` FOREIGN KEY (`mission_id`) REFERENCES `missions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `missions`;
CREATE TABLE `missions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mission_key` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `target_value` int(11) NOT NULL,
  `reward_coins` bigint(20) NOT NULL DEFAULT 0,
  `reward_stars` bigint(20) NOT NULL DEFAULT 0,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mission_key` (`mission_key`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `missions` (`id`,`mission_key`,`name`,`description`,`target_value`,`reward_coins`,`reward_stars`,`starts_at`,`ends_at`,`active`) VALUES ('1','weekly_variety','Parlor Sampler','Complete rounds in several games.','10','500','20','2026-07-14 13:06:04','2026-07-21 13:06:04','1');
INSERT INTO `missions` (`id`,`mission_key`,`name`,`description`,`target_value`,`reward_coins`,`reward_stars`,`starts_at`,`ends_at`,`active`) VALUES ('2','weekly_rules','Know the Tables','Visit five rules pages.','5','250','15','2026-07-14 13:06:04','2026-07-21 13:06:04','1');
INSERT INTO `missions` (`id`,`mission_key`,`name`,`description`,`target_value`,`reward_coins`,`reward_stars`,`starts_at`,`ends_at`,`active`) VALUES ('3','daily_rounds_2026-07-14','Daily Parlor Visit','Complete three play-money rounds today.','3','150','5','2026-07-14 00:00:00','2026-07-15 00:00:00','1');
INSERT INTO `missions` (`id`,`mission_key`,`name`,`description`,`target_value`,`reward_coins`,`reward_stars`,`starts_at`,`ends_at`,`active`) VALUES ('4','weekly_variety_2026-W29','Parlor Sampler','Complete ten rounds across the parlor.','10','500','20','2026-07-13 00:00:00','2026-07-20 00:00:00','1');
INSERT INTO `missions` (`id`,`mission_key`,`name`,`description`,`target_value`,`reward_coins`,`reward_stars`,`starts_at`,`ends_at`,`active`) VALUES ('5','weekly_rules_2026-W29','Know the Tables','Visit five rules pages.','5','250','15','2026-07-13 00:00:00','2026-07-20 00:00:00','1');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(100) NOT NULL,
  `data_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data_json`)),
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_attempts`;
CREATE TABLE `payment_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `provider` varchar(32) NOT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `status` varchar(32) NOT NULL,
  `failure_code` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `user_id` (`user_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `payment_attempts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `payment_attempts_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_audit_logs`;
CREATE TABLE `payment_audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actor_user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(64) NOT NULL,
  `target_id` varchar(191) DEFAULT NULL,
  `details_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details_json`)),
  `request_id` varchar(64) DEFAULT NULL,
  `entry_hash` varchar(64) NOT NULL,
  `previous_hash` varchar(64) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `actor_user_id` (`actor_user_id`),
  CONSTRAINT `payment_audit_logs_ibfk_1` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_idempotency_keys`;
CREATE TABLE `payment_idempotency_keys` (
  `idempotency_key` varchar(191) NOT NULL,
  `operation` varchar(100) NOT NULL,
  `request_hash` varchar(64) NOT NULL,
  `response_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_json`)),
  `status` varchar(32) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_provider_customers`;
CREATE TABLE `payment_provider_customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `provider` varchar(32) NOT NULL,
  `external_customer_id` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`,`external_customer_id`),
  UNIQUE KEY `user_id` (`user_id`,`provider`),
  CONSTRAINT `payment_provider_customers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `subscription_id` bigint(20) unsigned DEFAULT NULL,
  `provider` varchar(32) NOT NULL,
  `external_id` varchar(191) NOT NULL,
  `status` varchar(32) NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `receipt_url` varchar(500) DEFAULT NULL,
  `provider_metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`provider_metadata_json`)),
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`,`external_id`),
  KEY `product_id` (`product_id`),
  KEY `subscription_id` (`subscription_id`),
  KEY `idx_payments_user_created` (`user_id`,`created_at`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `CONSTRAINT_1` CHECK (`amount_cents` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('1','admin.access','Admin Access','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('2','users.view','Users View','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('3','users.manage','Users Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('4','users.roles.manage','Users Roles Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('5','content.manage','Content Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('6','games.manage','Games Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('7','virtual_currency.view','Virtual Currency View','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('8','virtual_currency.adjust','Virtual Currency Adjust','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('9','missions.manage','Missions Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('10','achievements.manage','Achievements Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('11','support.manage','Support Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('12','system.health.view','System Health View','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('13','system.settings.manage','System Settings Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('14','payments.summary.view','Payments Summary View','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('15','payments.audit.view','Payments Audit View','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('16','payments.refund','Payments Refund','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('17','payments.live.configure','Payments Live Configure','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('18','merchant.identity.manage','Merchant Identity Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('19','payout.settings.manage','Payout Settings Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('20','admins.manage','Admins Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('21','monetization.disable','Monetization Disable','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('22','audit.view','Audit View','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('23','backups.manage','Backups Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('24','legal.manage','Legal Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('25','ads.manage','Ads Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('26','billing.self.manage','Billing Self Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('27','profile.self.manage','Profile Self Manage','2026-07-14 13:06:04');
INSERT INTO `permissions` (`id`,`name`,`description`,`created_at`) VALUES ('28','games.play','Games Play','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `player_statistics`;
CREATE TABLE `player_statistics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `game_id` bigint(20) unsigned DEFAULT NULL,
  `stat_key` varchar(100) NOT NULL,
  `stat_value` bigint(20) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`game_id`,`stat_key`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `player_statistics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `player_statistics_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game_definitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `player_statistics` (`id`,`user_id`,`game_id`,`stat_key`,`stat_value`,`updated_at`) VALUES ('1','10','4','rounds','1','2026-07-14 16:59:20');
INSERT INTO `player_statistics` (`id`,`user_id`,`game_id`,`stat_key`,`stat_value`,`updated_at`) VALUES ('2','10','1','rounds','5','2026-07-14 16:59:20');

DROP TABLE IF EXISTS `product_entitlements`;
CREATE TABLE `product_entitlements` (
  `product_id` bigint(20) unsigned NOT NULL,
  `entitlement_key` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`,`entitlement_key`),
  CONSTRAINT `product_entitlements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `product_entitlements` (`product_id`,`entitlement_key`) VALUES ('1','theme.purple_premium');
INSERT INTO `product_entitlements` (`product_id`,`entitlement_key`) VALUES ('2','profile.royal_frame');
INSERT INTO `product_entitlements` (`product_id`,`entitlement_key`) VALUES ('3','theme.fireplace');
INSERT INTO `product_entitlements` (`product_id`,`entitlement_key`) VALUES ('4','profile.animated_crown');
INSERT INTO `product_entitlements` (`product_id`,`entitlement_key`) VALUES ('5','ads.disabled');
INSERT INTO `product_entitlements` (`product_id`,`entitlement_key`) VALUES ('6','founder.badge');

DROP TABLE IF EXISTS `product_prices`;
CREATE TABLE `product_prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `provider` varchar(32) NOT NULL,
  `provider_price_id` varchar(191) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`provider`,`currency`),
  CONSTRAINT `product_prices_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `CONSTRAINT_1` CHECK (`amount_cents` >= 0)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('1','1','399','USD','demo',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('2','1','399','USD','square',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('3','2','299','USD','demo',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('4','2','299','USD','square',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('5','3','399','USD','demo',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('6','3','399','USD','square',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('7','4','249','USD','demo',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('8','4','249','USD','square',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('9','5','1999','USD','demo',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('10','5','1999','USD','square',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('11','6','499','USD','demo',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `product_prices` (`id`,`product_id`,`amount_cents`,`currency`,`provider`,`provider_price_id`,`active`,`created_at`,`updated_at`) VALUES ('12','6','499','USD','square',NULL,'1','2026-07-14 13:06:04','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_key` varchar(100) NOT NULL,
  `provider_id` varchar(191) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `preview_path` varchar(255) DEFAULT NULL,
  `fixed_contents_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`fixed_contents_json`)),
  `entitlement_key` varchar(100) NOT NULL,
  `refund_policy_reference` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_key` (`product_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `products` (`id`,`product_key`,`provider_id`,`name`,`description`,`preview_path`,`fixed_contents_json`,`entitlement_key`,`refund_policy_reference`,`active`,`created_at`,`updated_at`) VALUES ('1','purple_theme_pack',NULL,'Royal Plum Theme','Permanent premium Royal Plum visual theme.',NULL,'[\"theme.purple_premium\"]','theme.purple_premium','refund-policy-v1','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `products` (`id`,`product_key`,`provider_id`,`name`,`description`,`preview_path`,`fixed_contents_json`,`entitlement_key`,`refund_policy_reference`,`active`,`created_at`,`updated_at`) VALUES ('2','royal_onion_profile_pack',NULL,'Royal Onion Profile Frame','Permanent fixed royal frame for the member profile.',NULL,'[\"profile.royal_frame\"]','profile.royal_frame','refund-policy-v1','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `products` (`id`,`product_key`,`provider_id`,`name`,`description`,`preview_path`,`fixed_contents_json`,`entitlement_key`,`refund_policy_reference`,`active`,`created_at`,`updated_at`) VALUES ('3','cozy_fireplace_soundtrack',NULL,'Cozy Fireplace Theme','Permanent cozy fireplace visual theme.',NULL,'[\"theme.fireplace\"]','theme.fireplace','refund-policy-v1','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `products` (`id`,`product_key`,`provider_id`,`name`,`description`,`preview_path`,`fixed_contents_json`,`entitlement_key`,`refund_policy_reference`,`active`,`created_at`,`updated_at`) VALUES ('4','animated_crown_decoration',NULL,'Animated Crown Decoration','A fixed profile decoration.',NULL,'[\"profile.animated_crown\"]','profile.animated_crown','refund-policy-v1','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `products` (`id`,`product_key`,`provider_id`,`name`,`description`,`preview_path`,`fixed_contents_json`,`entitlement_key`,`refund_policy_reference`,`active`,`created_at`,`updated_at`) VALUES ('5','lifetime_ad_free',NULL,'Lifetime Ad-Free Upgrade','Permanently disables display advertising for this account.',NULL,'[\"ads.disabled\"]','ads.disabled','refund-policy-v1','1','2026-07-14 13:06:04','2026-07-14 13:06:04');
INSERT INTO `products` (`id`,`product_key`,`provider_id`,`name`,`description`,`preview_path`,`fixed_contents_json`,`entitlement_key`,`refund_policy_reference`,`active`,`created_at`,`updated_at`) VALUES ('6','founder_supporter_badge',NULL,'Founder Supporter Badge','A fixed supporter profile badge.',NULL,'[\"founder.badge\"]','founder.badge','refund-policy-v1','1','2026-07-14 13:06:04','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `rate_limits`;
CREATE TABLE `rate_limits` (
  `bucket_key` varchar(191) NOT NULL,
  `hits` int(11) NOT NULL,
  `window_started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`bucket_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `recent_games`;
CREATE TABLE `recent_games` (
  `user_id` bigint(20) unsigned NOT NULL,
  `game_id` bigint(20) unsigned NOT NULL,
  `last_played_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`game_id`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `recent_games_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recent_games_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game_definitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `recovery_codes`;
CREATE TABLE `recovery_codes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `recovery_codes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `refund_executions`;
CREATE TABLE `refund_executions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `refund_request_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  `provider` varchar(32) NOT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'not_started',
  `provider_refund_id` varchar(191) DEFAULT NULL,
  `provider_status` varchar(64) DEFAULT NULL,
  `attempt_count` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refund_request_id` (`refund_request_id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `idx_refund_executions_payment_status` (`payment_id`,`status`),
  CONSTRAINT `refund_executions_ibfk_1` FOREIGN KEY (`refund_request_id`) REFERENCES `refund_requests` (`id`),
  CONSTRAINT `refund_executions_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`amount_cents` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `refund_requests`;
CREATE TABLE `refund_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) unsigned NOT NULL,
  `requested_amount_cents` bigint(20) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'requested',
  `request_reason` varchar(500) NOT NULL,
  `resolution_note` varchar(500) DEFAULT NULL,
  `requested_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `requested_by` (`requested_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_refund_requests_status` (`status`,`updated_at`),
  CONSTRAINT `refund_requests_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `refund_requests_ibfk_2` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `refund_requests_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `CONSTRAINT_1` CHECK (`requested_amount_cents` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `refunds`;
CREATE TABLE `refunds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) unsigned NOT NULL,
  `provider` varchar(32) NOT NULL,
  `external_id` varchar(191) NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `status` varchar(32) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`,`external_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `refunds_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`amount_cents` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `selector` varchar(32) NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `selector` (`selector`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `remember_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `remember_tokens` (`id`,`user_id`,`selector`,`token_hash`,`expires_at`,`last_used_at`,`created_at`) VALUES ('12','10','16a8c2b09c7596b25864c18d','7f1324fc6f2247f5998ee347fd0772ecc63b3f8b9e8bc2349566b28d75bb8255','2026-08-13 17:03:20',NULL,'2026-07-14 17:03:20');

DROP TABLE IF EXISTS `responsible_play_controls`;
CREATE TABLE `responsible_play_controls` (
  `user_id` bigint(20) unsigned NOT NULL,
  `session_reminder_minutes` int(11) DEFAULT NULL,
  `daily_limit_minutes` int(11) DEFAULT NULL,
  `cooldown_until` datetime DEFAULT NULL,
  `self_excluded_until` datetime DEFAULT NULL,
  `autoplay_allowed` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `responsible_play_controls_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','1');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','2');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','3');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','4');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','5');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','6');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','7');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','8');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','9');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','10');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','11');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','12');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','13');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','14');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','15');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','16');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','17');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','18');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','19');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','20');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','21');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','22');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','23');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','24');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','25');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','26');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','27');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('1','28');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','1');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','2');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','3');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','5');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','6');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','7');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','8');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','9');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','10');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','11');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','12');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','13');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','14');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','22');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','24');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','27');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('2','28');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('3','1');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('3','2');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('3','11');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('3','14');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('3','27');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('3','28');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','1');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','5');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','6');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','9');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','10');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','27');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('4','28');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('5','1');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('5','2');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('5','11');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('5','27');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('5','28');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('6','26');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('6','27');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('6','28');
INSERT INTO `role_permissions` (`role_id`,`permission_id`) VALUES ('7','28');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('1','adult_owner','Adult Owner','2026-07-14 13:06:04');
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('2','developer_admin','Developer Admin','2026-07-14 13:06:04');
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('3','support_admin','Support Admin','2026-07-14 13:06:04');
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('4','content_manager','Content Manager','2026-07-14 13:06:04');
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('5','moderator','Moderator','2026-07-14 13:06:04');
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('6','member','Member','2026-07-14 13:06:04');
INSERT INTO `roles` (`id`,`name`,`description`,`created_at`) VALUES ('7','guest','Guest','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `migration` varchar(255) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  PRIMARY KEY (`migration`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('001_initial_schema.php','c07f8f3e41472c79c704a9f731fcc05809e75bd53d831f302c6b637e6ee77f09','2026-07-14 13:06:03');
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('002_account_controls.php','b054f7f885432d45830b38304c0a8e1a4ccb8559cb4e568ed2510012de4cc855','2026-07-14 13:06:03');
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('003_game_seed_queue.php','c07f8f3e41472c79c704a9f731fcc05809e75bd53d831f302c6b637e6ee77f09','2026-07-14 13:06:03');
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('004_checkout_intents.php','c07f8f3e41472c79c704a9f731fcc05809e75bd53d831f302c6b637e6ee77f09','2026-07-14 13:06:03');
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('005_admin_management.php','6de8ecfb4bcb56a0d1056ef5d5c634cae738884d1f5e0d97424f29cb8057980f','2026-07-14 13:06:04');
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('006_refund_execution.php','c07f8f3e41472c79c704a9f731fcc05809e75bd53d831f302c6b637e6ee77f09','2026-07-14 13:06:04');
INSERT INTO `schema_migrations` (`migration`,`checksum`,`applied_at`) VALUES ('007_managed_content.php','c07f8f3e41472c79c704a9f731fcc05809e75bd53d831f302c6b637e6ee77f09','2026-07-14 13:06:04');

DROP TABLE IF EXISTS `security_events`;
CREATE TABLE `security_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(100) NOT NULL,
  `severity` varchar(20) NOT NULL,
  `ip_hash` varchar(64) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata_json`)),
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_security_events_created` (`event_type`,`created_at`),
  CONSTRAINT `security_events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `security_events` (`id`,`user_id`,`event_type`,`severity`,`ip_hash`,`request_id`,`metadata_json`,`created_at`) VALUES ('4','10','registration','info','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5',NULL,NULL,'2026-07-14 16:59:20');
INSERT INTO `security_events` (`id`,`user_id`,`event_type`,`severity`,`ip_hash`,`request_id`,`metadata_json`,`created_at`) VALUES ('5','10','login_succeeded','info','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5',NULL,NULL,'2026-07-14 17:02:26');

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `selector` varchar(32) NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `php_session_id` varchar(128) DEFAULT NULL,
  `ip_hash` varchar(64) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `last_seen_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `selector` (`selector`),
  KEY `idx_sessions_user_active` (`user_id`,`revoked_at`,`expires_at`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('1','10','ff5fbef245ab0bda92f8dae0','b31c7036cd15a61634244a004bee24375dd0264ef5a654fc2355865d175a209d','cfe6304a249ba60e18c8cee7966b2a5f','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:26','2026-07-14 19:02:26',NULL,'2026-07-14 17:02:26');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('2','10','e884167d69e5cc8b7a8f2ea9','0daecd000bd39a88ca788590dbdb5191d06a4d2bbb654d7b59fab8f43e4d9f49','4da9cb0888c27d9e012135746c199909','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:26','2026-07-14 19:02:26',NULL,'2026-07-14 17:02:26');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('3','10','9b1cf22eb290976f4ba777f4','edee6daa5da4a959bcfec4755bb635233f3bc03353598c20721cd09680e0e501','9ad0e7205e76a8222adfc516c5938cd6','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:30','2026-07-14 19:02:30',NULL,'2026-07-14 17:02:30');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('4','10','c1b0f09a203619043d2f0895','542bcbb6ed969292a02bffa4c076a474584ee6f57a5f921991c6d8120efaf5e7','4f3dabd1c9b637f56332992b48d5445f','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:32','2026-07-14 19:02:32',NULL,'2026-07-14 17:02:32');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('5','10','aad885bbacfca7bcb2fac869','e818aa60ff67d9d157238db92e910247f4e769f3fc35b6c0ccc9224f5596a8e8','7b042b98c4113987d713441418c07451','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:34','2026-07-14 19:02:34',NULL,'2026-07-14 17:02:34');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('6','10','a0fab1d2f2f8bc54516562b1','f8e4cca4dda8c9b1e8228fa867146e9b87987de9c88e45518044ee65d186e31e','6db1ddbd50f9cd5af5dab46e9bd55fbf','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:39','2026-07-14 19:02:39',NULL,'2026-07-14 17:02:39');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('7','10','746bce2972759dd663fe733a','7af1c54c971bda1a0aac14552f2015cdd6393a170e9de13d236e2d53023ae526','aa04a9150c7b57f8d841f0a98827a109','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:42','2026-07-14 19:02:42',NULL,'2026-07-14 17:02:42');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('8','10','3a9ee9ae86b940d6320341b5','339f689f7de8d4f159808612d95c1fb04bd35cc7e806b8bc298facd076f9c987','5256cbb96c0b0c3bcd3b4b3cccb68731','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:02:46','2026-07-14 19:02:46',NULL,'2026-07-14 17:02:46');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('9','10','d40ab2c0d291a3133224aeb1','cf94473b7f1e34a810a4ae9bafac4ade11b7a42f0d09c8644aba2802521a78dc','d4fb03385f347200a15daa6cec8795af','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:03:03','2026-07-14 19:03:03',NULL,'2026-07-14 17:03:03');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('10','10','f9827cb5a5fbc2c02ca4e480','3ced45b9b0af9223b5f00c7dcf7b96cff5ea0eddf233edd6554e354658072366','f0090e2298cc0ab1b56d66c8d2f8672c','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:03:12','2026-07-14 19:03:12',NULL,'2026-07-14 17:03:12');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('11','10','5dfe7d19516dd26b3e09ae5b','444061b55eb0258921a3756b483c47c0165f2b16b1f63b4c33b9d7a187eade73','47bcc843221c9065350f0f2f0a60e8ef','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 17:03:14','2026-07-14 19:03:14',NULL,'2026-07-14 17:03:14');
INSERT INTO `sessions` (`id`,`user_id`,`selector`,`token_hash`,`php_session_id`,`ip_hash`,`user_agent`,`last_seen_at`,`expires_at`,`revoked_at`,`created_at`) VALUES ('12','10','9675ca0fed0a7a6c5673004e','e7462bc7d5a0f0ebf0cc8162f8e1e95983aa2bb5713a3370dbc5ab5d138ccb53','e4f4ea42f2e6025d69f3b0f7ff9b9475','fec41a6aea2552af6c97b0074c9556d28945ea86effe22dc9eda9c0e5ad446d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-14 18:45:09','2026-07-14 19:03:20',NULL,'2026-07-14 17:03:20');

DROP TABLE IF EXISTS `sponsors`;
CREATE TABLE `sponsors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `website_url` varchar(500) DEFAULT NULL,
  `status` varchar(32) NOT NULL,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata_json`)),
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `subscription_events`;
CREATE TABLE `subscription_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint(20) unsigned NOT NULL,
  `provider_event_id` varchar(191) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `status_before` varchar(32) DEFAULT NULL,
  `status_after` varchar(32) NOT NULL,
  `event_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`event_json`)),
  `occurred_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider_event_id` (`provider_event_id`),
  KEY `subscription_id` (`subscription_id`),
  CONSTRAINT `subscription_events_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE `subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned NOT NULL,
  `provider` varchar(32) NOT NULL,
  `external_id` varchar(191) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'pending',
  `billing_period` varchar(16) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `amount_cents` bigint(20) NOT NULL,
  `current_period_start` datetime DEFAULT NULL,
  `current_period_end` datetime DEFAULT NULL,
  `grace_ends_at` datetime DEFAULT NULL,
  `cancel_at_period_end` tinyint(1) NOT NULL DEFAULT 0,
  `canceled_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`,`external_id`),
  KEY `plan_id` (`plan_id`),
  KEY `idx_subscriptions_user_status` (`user_id`,`status`),
  CONSTRAINT `subscriptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `membership_plans` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `support_tickets`;
CREATE TABLE `support_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `subject` varchar(150) NOT NULL,
  `status` varchar(32) NOT NULL,
  `priority` varchar(16) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `support_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `setting_key` varchar(191) NOT NULL,
  `setting_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`setting_value`)),
  `is_sensitive` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`setting_key`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `system_settings_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`is_sensitive`,`updated_by`,`updated_at`) VALUES ('payments.demo_scenarios','[\"success\",\"failed\",\"pending\",\"canceled\",\"renewal\",\"failed_renewal\",\"grace\",\"expiration\",\"refund\",\"dispute\",\"duplicate\",\"invalid_signature\"]','0',NULL,'2026-07-14 13:06:04');
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`is_sensitive`,`updated_by`,`updated_at`) VALUES ('payments.production_locked','true','0',NULL,'2026-07-14 13:06:04');
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`is_sensitive`,`updated_by`,`updated_at`) VALUES ('site.brand','{\"name\":\"The Purple Parlor\",\"creator\":\"Lord Funion\"}','0',NULL,'2026-07-14 13:06:04');
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`is_sensitive`,`updated_by`,`updated_at`) VALUES ('site.theme','{\"default\":\"purple-parlor\",\"available\":[\"purple-parlor\",\"midnight-lavender\",\"cozy-fireplace\",\"royal-plum\",\"soft-daylight\",\"high-contrast\"]}','0',NULL,'2026-07-14 13:06:04');
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`is_sensitive`,`updated_by`,`updated_at`) VALUES ('system.health.last_snapshot','{\"checked_at\":\"2026-07-14 19:00:01\",\"source\":\"cron\",\"passed\":29,\"total\":31,\"checks\":{\"php_version\":{\"ok\":true,\"detail\":\"8.4.21\"},\"extension_pdo\":{\"ok\":true,\"detail\":\"loaded\"},\"extension_openssl\":{\"ok\":true,\"detail\":\"loaded\"},\"extension_json\":{\"ok\":true,\"detail\":\"loaded\"},\"extension_filter\":{\"ok\":true,\"detail\":\"loaded\"},\"extension_session\":{\"ok\":true,\"detail\":\"loaded\"},\"extension_mbstring\":{\"ok\":true,\"detail\":\"loaded\"},\"extension_pdo_mysql\":{\"ok\":true,\"detail\":\"loaded\"},\"recommended_curl\":{\"ok\":true,\"detail\":\"loaded\"},\"recommended_fileinfo\":{\"ok\":true,\"detail\":\"loaded\"},\"recommended_intl\":{\"ok\":true,\"detail\":\"loaded\"},\"recommended_sodium\":{\"ok\":true,\"detail\":\"loaded\"},\"database\":{\"ok\":true,\"detail\":\"mysql\"},\"database_schema\":{\"ok\":true,\"detail\":\"28 critical tables and 131 critical columns verified\"},\"append_only_triggers\":{\"ok\":true,\"detail\":\"8 of 8 append-only trigger guards verified\"},\"writable_storage_logs\":{\"ok\":true,\"detail\":\"storage/logs\"},\"writable_storage_cache\":{\"ok\":true,\"detail\":\"storage/cache\"},\"writable_storage_sessions\":{\"ok\":true,\"detail\":\"storage/sessions\"},\"writable_storage_temporary\":{\"ok\":true,\"detail\":\"storage/temporary\"},\"writable_storage_backups\":{\"ok\":true,\"detail\":\"storage/backups\"},\"private_config_placement\":{\"ok\":true,\"detail\":\"environment and configuration are outside the public document root\"},\"private_config_permissions\":{\"ok\":false,\"detail\":\"use mode 600 for the environment file and remove group/other write access from configuration\"},\"apache_protection_files\":{\"ok\":true,\"detail\":\"4 of 4 required Apache protection files verified\"},\"app_key\":{\"ok\":true,\"detail\":\"configured\"},\"debug\":{\"ok\":true,\"detail\":\"disabled\"},\"secure_session_cookie\":{\"ok\":true,\"detail\":\"secure\"},\"mail_configuration\":{\"ok\":true,\"detail\":\"mail configured\"},\"cron_freshness\":{\"ok\":true,\"detail\":\"2026-07-14 19:00:01\"},\"backup_freshness\":{\"ok\":false,\"detail\":\"never\"},\"disk_space\":{\"ok\":true,\"detail\":\"875254 MiB free\"},\"payments_live_lock\":{\"ok\":true,\"detail\":\"locked/non-live\"}}}','0',NULL,'2026-07-14 19:00:02');
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`is_sensitive`,`updated_by`,`updated_at`) VALUES ('virtual_currency.disclaimer','\"Virtual currency has no cash value, is not sold separately, and cannot be transferred, redeemed, withdrawn, or exchanged for anything of value.\"','0',NULL,'2026-07-14 19:02:28');

DROP TABLE IF EXISTS `two_factor_secrets`;
CREATE TABLE `two_factor_secrets` (
  `user_id` bigint(20) unsigned NOT NULL,
  `encrypted_secret` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `confirmed_at` datetime DEFAULT NULL,
  `last_counter` bigint(20) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `two_factor_secrets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_achievements`;
CREATE TABLE `user_achievements` (
  `user_id` bigint(20) unsigned NOT NULL,
  `achievement_id` bigint(20) unsigned NOT NULL,
  `unlocked_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`achievement_id`),
  KEY `achievement_id` (`achievement_id`),
  CONSTRAINT `user_achievements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_achievements_ibfk_2` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `user_achievements` (`user_id`,`achievement_id`,`unlocked_at`) VALUES ('10','1','2026-07-14 17:02:20');

DROP TABLE IF EXISTS `user_entitlements`;
CREATE TABLE `user_entitlements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `entitlement_key` varchar(100) NOT NULL,
  `source_type` varchar(32) NOT NULL,
  `source_id` varchar(191) NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `revocation_reason` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`entitlement_key`,`source_type`,`source_id`),
  KEY `idx_entitlements_active` (`user_id`,`entitlement_key`,`revoked_at`,`ends_at`),
  CONSTRAINT `user_entitlements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_profiles`;
CREATE TABLE `user_profiles` (
  `user_id` bigint(20) unsigned NOT NULL,
  `display_name` varchar(80) DEFAULT NULL,
  `bio` varchar(500) DEFAULT NULL,
  `avatar_key` varchar(100) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `stats_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `user_profiles` (`user_id`,`display_name`,`bio`,`avatar_key`,`is_public`,`stats_public`,`created_at`,`updated_at`) VALUES ('10','lordfunion',NULL,NULL,'0','0','2026-07-14 16:59:20','2026-07-14 16:59:20');

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `granted_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  KEY `granted_by` (`granted_by`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_3` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `user_roles` (`user_id`,`role_id`,`granted_by`,`created_at`) VALUES ('10','6',NULL,'2026-07-14 16:59:20');

DROP TABLE IF EXISTS `user_settings`;
CREATE TABLE `user_settings` (
  `user_id` bigint(20) unsigned NOT NULL,
  `settings_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`settings_json`)),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `user_settings` (`user_id`,`settings_json`,`updated_at`) VALUES ('10','{\"notifications\":{\"news\":false},\"analytics_opt_out\":true}','2026-07-14 16:59:20');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(254) NOT NULL,
  `email_normalized` varchar(254) NOT NULL,
  `username` varchar(50) NOT NULL,
  `username_normalized` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'pending_verification',
  `email_verified_at` datetime DEFAULT NULL,
  `pending_email` varchar(254) DEFAULT NULL,
  `failed_login_count` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `username_changed_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_normalized` (`email_normalized`),
  UNIQUE KEY `username_normalized` (`username_normalized`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `users` (`id`,`email`,`email_normalized`,`username`,`username_normalized`,`password_hash`,`status`,`email_verified_at`,`pending_email`,`failed_login_count`,`locked_until`,`username_changed_at`,`last_login_at`,`created_at`,`updated_at`,`deleted_at`) VALUES ('10','lordfunion@gmail.com','lordfunion@gmail.com','lordfunion','lordfunion','$argon2id$v=19$m=65536,t=4,p=1$VDNIcjAyMUNkRUl1dlAyZg$EZgnRZzwOcXN4uPH+bdCrNMxclshX8uDP/RIJGPT30w','active','2026-07-14 17:02:20',NULL,'0',NULL,NULL,'2026-07-14 17:02:26','2026-07-14 16:59:20','2026-07-14 17:02:26',NULL);

DROP TABLE IF EXISTS `virtual_ledger_entries`;
CREATE TABLE `virtual_ledger_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `currency` varchar(32) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `balance_before` bigint(20) NOT NULL,
  `balance_after` bigint(20) NOT NULL,
  `reason_code` varchar(100) NOT NULL,
  `related_game_round_id` bigint(20) unsigned DEFAULT NULL,
  `related_achievement_id` bigint(20) unsigned DEFAULT NULL,
  `related_mission_id` bigint(20) unsigned DEFAULT NULL,
  `administrator_id` bigint(20) unsigned DEFAULT NULL,
  `idempotency_key` varchar(191) NOT NULL,
  `previous_hash` varchar(64) NOT NULL,
  `entry_hash` varchar(64) NOT NULL,
  `metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata_json`)),
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `administrator_id` (`administrator_id`),
  KEY `idx_ledger_user_currency` (`user_id`,`currency`,`id`),
  CONSTRAINT `virtual_ledger_entries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `virtual_ledger_entries_ibfk_2` FOREIGN KEY (`administrator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `CONSTRAINT_1` CHECK (`balance_after` >= 0),
  CONSTRAINT `CONSTRAINT_2` CHECK (`balance_after` = `balance_before` + `amount`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `virtual_ledger_entries` (`id`,`user_id`,`currency`,`amount`,`balance_before`,`balance_after`,`reason_code`,`related_game_round_id`,`related_achievement_id`,`related_mission_id`,`administrator_id`,`idempotency_key`,`previous_hash`,`entry_hash`,`metadata_json`,`created_at`) VALUES ('5','10','cozy_coins','10000','0','10000','account.initial_grant',NULL,NULL,NULL,NULL,'registration:coins:10','0000000000000000000000000000000000000000000000000000000000000000','bc672a2c222ab9bdcc3d80bb5b83a5c7c24f9738b5feb37eda8d6f73f3875d8f',NULL,'2026-07-14 16:59:20');
INSERT INTO `virtual_ledger_entries` (`id`,`user_id`,`currency`,`amount`,`balance_before`,`balance_after`,`reason_code`,`related_game_round_id`,`related_achievement_id`,`related_mission_id`,`administrator_id`,`idempotency_key`,`previous_hash`,`entry_hash`,`metadata_json`,`created_at`) VALUES ('6','10','parlor_stars','100','0','100','account.initial_grant',NULL,NULL,NULL,NULL,'registration:stars:10','0000000000000000000000000000000000000000000000000000000000000000','dff2ec5c4feadbb0046b1bae7b5df506b86582215913acb4943720c286beca9b',NULL,'2026-07-14 16:59:20');
INSERT INTO `virtual_ledger_entries` (`id`,`user_id`,`currency`,`amount`,`balance_before`,`balance_after`,`reason_code`,`related_game_round_id`,`related_achievement_id`,`related_mission_id`,`administrator_id`,`idempotency_key`,`previous_hash`,`entry_hash`,`metadata_json`,`created_at`) VALUES ('7','10','parlor_stars','25','100','125','reward.achievement',NULL,'1',NULL,NULL,'achievement:stars:10:1','dff2ec5c4feadbb0046b1bae7b5df506b86582215913acb4943720c286beca9b','2276008778b7ab5e5cb8885335ac3f716df1c15b6479feff91612caf6af03ee9',NULL,'2026-07-14 17:02:20');

DROP TABLE IF EXISTS `virtual_wallets`;
CREATE TABLE `virtual_wallets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `currency` varchar(32) NOT NULL,
  `balance` bigint(20) NOT NULL DEFAULT 0,
  `version` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`currency`),
  CONSTRAINT `virtual_wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `CONSTRAINT_1` CHECK (`balance` >= 0)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `virtual_wallets` (`id`,`user_id`,`currency`,`balance`,`version`,`created_at`,`updated_at`) VALUES ('5','10','cozy_coins','10000','1','2026-07-14 16:59:20','2026-07-14 16:59:20');
INSERT INTO `virtual_wallets` (`id`,`user_id`,`currency`,`balance`,`version`,`created_at`,`updated_at`) VALUES ('6','10','parlor_stars','125','2','2026-07-14 16:59:20','2026-07-14 17:02:20');

DROP TABLE IF EXISTS `webhook_events`;
CREATE TABLE `webhook_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(32) NOT NULL,
  `provider_event_id` varchar(191) NOT NULL,
  `event_type` varchar(150) NOT NULL,
  `signature_valid` int(11) NOT NULL,
  `status` varchar(32) NOT NULL,
  `payload_hash` varchar(64) NOT NULL,
  `payload_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload_json`)),
  `error_message` varchar(500) DEFAULT NULL,
  `received_at` datetime NOT NULL,
  `processed_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`,`provider_event_id`),
  KEY `idx_webhook_status` (`status`,`received_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TRIGGER IF EXISTS `protect_admin_audit_logs_update`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_admin_audit_logs_update BEFORE UPDATE ON admin_audit_logs FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_admin_audit_logs_delete`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_admin_audit_logs_delete BEFORE DELETE ON admin_audit_logs FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_payment_audit_logs_update`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_payment_audit_logs_update BEFORE UPDATE ON payment_audit_logs FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_payment_audit_logs_delete`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_payment_audit_logs_delete BEFORE DELETE ON payment_audit_logs FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_subscription_events_update`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_subscription_events_update BEFORE UPDATE ON subscription_events FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_subscription_events_delete`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_subscription_events_delete BEFORE DELETE ON subscription_events FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_virtual_ledger_entries_update`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_virtual_ledger_entries_update BEFORE UPDATE ON virtual_ledger_entries FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';

DROP TRIGGER IF EXISTS `protect_virtual_ledger_entries_delete`;
CREATE DEFINER=`purpleapp`@`localhost` TRIGGER protect_virtual_ledger_entries_delete BEFORE DELETE ON virtual_ledger_entries FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'append-only table';
SET FOREIGN_KEY_CHECKS=1;
